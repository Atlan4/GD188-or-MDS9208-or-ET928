/*
 * scope.h
 *
 *  Osciloskop: zachytávanie cez časovače a DMA, mriežka, rozsahy V/div, časová základňa,
 *  spúšťanie (trigger) AUTO / NORM / SINGLE. Spúšťa sa dlhým AUTO v polohe V alebo mV (main.c).
 *
 *  Hardvér:
 *    MS9280: dáta PC0–PC7, hodiny PC12 = TIM11_CH1 (AF3), STBY PA10 (1 = úsporný režim)
 *    TIM1 (rovnaký takt 100 MHz) generuje DMA požiadavky: DMA2 Stream5 kanál 6 (TIM1_UP)
 *    číta GPIOC->IDR do zásobníka v nízkej fáze hodín ADC.
 *    Vstup: relé AC/DC PA9 (1 = AC), relé 1/10 PA8, O1O2 PA15 (1:10 iba s relé 1/10 -> 1:100),
 *    U6 PC10 (x4), U7 PC11 (x2). Poloha mV je 10x citlivejšia (prepínač vynechá delič).
 *
 *  Ovládanie:
 *    hlavné menu:  F1 V/DIV, F2 TIME, F3 TRIG, F4 RUN/STOP
 *                  F1 dlho = menu osciloskopu, F2 dlho = menu meraní, F3 dlho = všetky merania áno / nie
 *    V/DIV:        F1 EXIT, F2 SENS-, F3 SENS+, F4 AC/DC; F2 / F3 držané = posun stopy dole / hore
 *    TIME:         F1 EXIT, F2 TIME-, F3 TIME+ (držané = vodorovný posun), F4 ROLL
 *    TRIG:         F1 EXIT, F2 LEVEL-, F3 LEVEL+ (držané = opakovanie), F4 hrana; AUTO krátko = režim
 *    AUTO krátko = autoset (mimo TRIG), AUTO dlho = odchod
 *    SAVE krátko = pamäte priebehov (F4 LOAD, SAVE = uložiť), SAVE dlho = posledné nastavenie do EEPROM
 *    TIME F4 = ROLL (od 100 ms/div; nad 200 ms/div vždy); menu osciloskopu: Trig position, Calibration, Test mode
 */

#ifndef INC_SCOPE_H_
#define INC_SCOPE_H_

#include <stdint.h>
#include <stdbool.h>
#include "button.h"

typedef enum {
    SCOPE_STAY = 0,
    SCOPE_EXIT,          // dlhé AUTO -> odchod na voltmeter
    SCOPE_TEST           // menu osciloskopu -> testovací režim
} ScopeAction_t;

// Stav na pokračovanie po zobudení (main.c, Resume_t)
typedef struct {
    uint8_t vdiv_v;      // index rozsahu V/div v polohe V
    uint8_t vdiv_mv;     // index rozsahu V/div v polohe mV
    uint8_t tb;          // index časovej základne
    uint8_t ac;          // 1 = AC väzba
    int8_t  offset;      // zvislá poloha stopy v krokoch 1/5 dielika
    uint8_t slope;       // 0 = nábežná hrana, 1 = dobežná
    uint8_t mode;        // 0 = AUTO, 1 = NORM, 2 = SINGLE
    uint8_t tpos;        // bod spustenia: 0 = 1/4, 1 = stred, 2 = 3/4 šírky
    int32_t trig_mv;     // úroveň spúšťania v mV (na vstupe)
    uint16_t meas_mask;  // vybrané merania (bit = MEAS_*), najviac 4
    uint8_t meas_show;   // 1 = riadok s vybranými meraniami zapnutý
    uint8_t meas_all;    // 1 = panel so všetkými meraniami (dlhé F3)
    uint8_t roll;        // 1 = ROLL (časové základne od 100 ms/div; nad 200 ms/div vždy)
    int16_t hpos;        // vodorovný posun v px (+ = neskôr)
    uint8_t hkeep;       // 1 = pri zmene TIME zachovať čas posunu (KEEP), 0 = vynulovať
    uint8_t delay_idx;   // oneskorenie záznamu po spustení (0 = OFF)
} ScopeState_t;

void          Scope_Open(bool mv_pos);              // nakreslí obrazovku, spustí ADC a zachytávanie
void          Scope_Close(void);                    // zastaví časovače a DMA, relé do 0, ADC do STBY
ScopeAction_t Scope_Task(ButtonType_t ev, bool mv_pos);
const char   *Scope_TopText(void);                  // horný riadok ako text (jednofarebne)
void          Scope_DrawTitle(uint16_t y, bool force); // horný riadok farebne (medzi časovačom a batériou)
void          Scope_GetState(ScopeState_t *st);
void          Scope_SetState(const ScopeState_t *st);
void          Scope_LoadEeprom(bool setup);
// Kalibrácia deliča 1:10 / 1:100: main.c prepne čip na DC V a posiela napätie (základ 0.1 mV)
bool          Scope_MeterWanted(void);
void          Scope_SetMeterReading(bool ok, int32_t v01mv);        // pri štarte: kalibrácia; setup = aj posledné nastavenie (nie po zobudení)

#endif /* INC_SCOPE_H_ */
