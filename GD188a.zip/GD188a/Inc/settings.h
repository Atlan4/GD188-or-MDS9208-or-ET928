/*
 * settings.h
 *
 *  Užívateľské nastavenia uložené v I2C EEPROM (viď eeprom_map.h).
 *  Načítajú sa pri štarte (aj po zobudení zo spánku – to je reset).
 */

#ifndef SETTINGS_H_
#define SETTINGS_H_

#include <stdint.h>
#include <stdbool.h>

#define SETTINGS_AUTO_OFF_MIN_MIN   1
#define SETTINGS_AUTO_OFF_MIN_MAX   99
#define SETTINGS_GEN_OFF_MAX        120     // generátor / osciloskop: 0 = OFF, krok 5 min
#define SETTINGS_GEN_OFF_STEP       5

typedef struct {
    uint8_t auto_off_min;   // čas do automatického vypnutia v minútach (1..99), predvolene 10
    bool    auto_reset;     // ON = tlačidlo / prepínač reštartuje odpočet
    bool    probe_reset;    // ON = v Ω / dióde / pípaku prechod z OL na hodnotu reštartuje odpočet
    uint8_t gen_off_min;    // auto vypnutie v generátore / osciloskope (0 = OFF, 5..120 po 5 min)
    // Posledné nastavenie generátora (indexy do zoznamov v gen.c); výstup ON/OFF sa neukladá
    uint8_t gen_wave;
    uint8_t gen_freq;
    uint8_t gen_duty;
    uint8_t gen_volt;
} AppSettings_t;

extern AppSettings_t g_settings;

void Settings_Load(void);    // pri neplatných dátach nastaví predvolené hodnoty
bool Settings_Save(void);    // zapíše iba ak sa líšia od uložených; true = OK

#endif /* SETTINGS_H_ */
