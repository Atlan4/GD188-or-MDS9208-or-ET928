/*
 * settings.h
 *
 *  Užívateľské nastavenia uložené v I2C EEPROM (viď eeprom_map.h).
 *  Načítajú sa pri štarte (aj po zobudení zo spánku – to je reset).
 */

#ifndef SETTINGS_H_
#define SETTINGS_H_

#include <stdint.h>
#include <stdbool.h>

#define SETTINGS_AUTO_OFF_MIN_MIN   1
#define SETTINGS_AUTO_OFF_MIN_MAX   99

typedef struct {
    uint8_t auto_off_min;   // čas do automatického vypnutia v minútach (1..99), predvolene 10
    bool    auto_reset;     // ON = tlačidlo / prepínač reštartuje odpočet
    bool    probe_reset;    // ON = v Ω / dióde / pípaku prechod z OL na hodnotu reštartuje odpočet
} AppSettings_t;

extern AppSettings_t g_settings;

void Settings_Load(void);    // pri neplatných dátach nastaví predvolené hodnoty
bool Settings_Save(void);    // zapíše iba ak sa líšia od uložených; true = OK

#endif /* SETTINGS_H_ */
