/*
 * gen_menu.h
 *
 *  Obrazovka generátora (otvára sa dlhým stlačením tlačidla podsvietenia v polohe V).
 */

#ifndef INC_GEN_MENU_H_
#define INC_GEN_MENU_H_

#include <stdbool.h>
#include "button.h"

void GenMenu_Open(void);              // vykreslí celú obrazovku (okrem horného riadku)
void GenMenu_Task(ButtonType_t ev);   // tlačidlá F1–F4, SAVE; prekreslí zmeny
void GenMenu_Close(void);             // zavrie prípadný zoznam (pred odchodom z obrazovky)

#endif /* INC_GEN_MENU_H_ */
