/*
 * eeprom_map.h
 *
 *  Rozdelenie EEPROM BL24C256A (32 KB, stránka 64 B, I2C1 na PB8 = SCL, PB9 = SDA).
 *
 *  Pravidlo: každá oblasť začína na začiatku stránky (násobok 64), aby zápis jednej
 *  oblasti nikdy nezasiahol do inej a aby jeden zápis stránky = jedna oblasť.
 *
 *   Adresa          Veľkosť   Obsah
 *   0x0000-0x003F    64 B     Nastavenia – kópia A (32 B záznam + rezerva)
 *   0x0040-0x007F    64 B     Nastavenia – kópia B
 *   0x0080-0x00FF   128 B     Pamäte generátora 1..10 (8 B na pamäť, viď gen_preset.c)
 *   0x0100-0x03FF   768 B     Rezerva: kalibrácia, ďalšie nastavenia (12 stránok)
 *   0x0400-0x7FFF  31 KB      Záznamy osciloskopu / dátový záznam (496 stránok)
 *
 *  Dve kópie nastavení sa zapisujú striedavo s počítadlom – ak sa zápis preruší
 *  (vypnutie napájania), zostane platná predchádzajúca kópia.
 */

#ifndef EEPROM_MAP_H_
#define EEPROM_MAP_H_

#define EE_SIZE                 32768u
#define EE_PAGE_SIZE            64u

#define EE_SETTINGS_A_ADDR      0x0000u
#define EE_SETTINGS_B_ADDR      0x0040u
#define EE_SETTINGS_SLOT_SIZE   64u

#define EE_PRESETS_ADDR         0x0080u     // pamäte generátora (2 stránky)
#define EE_PRESETS_SIZE         0x0080u

#define EE_RESERVED_ADDR        0x0100u     // kalibrácia a budúce nastavenia
#define EE_RESERVED_SIZE        (0x0400u - 0x0100u)

#define EE_RECORDS_ADDR         0x0400u     // záznamy osciloskopu
#define EE_RECORDS_SIZE         (EE_SIZE - EE_RECORDS_ADDR)

#endif /* EEPROM_MAP_H_ */
