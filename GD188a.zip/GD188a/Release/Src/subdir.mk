################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Src/battery.c \
../Src/beep.c \
../Src/button.c \
../Src/eeprom.c \
../Src/gen.c \
../Src/gen_menu.c \
../Src/gen_preset.c \
../Src/gpio.c \
../Src/lcd.c \
../Src/main.c \
../Src/meas_chip.c \
../Src/menu.c \
../Src/rotary_switch.c \
../Src/scope.c \
../Src/scope_test.c \
../Src/settings.c \
../Src/stm32f4xx_hal_msp.c \
../Src/stm32f4xx_it.c \
../Src/syscalls.c \
../Src/sysmem.c \
../Src/system_stm32f4xx.c \
../Src/tim.c \
../Src/usart.c 

OBJS += \
./Src/battery.o \
./Src/beep.o \
./Src/button.o \
./Src/eeprom.o \
./Src/gen.o \
./Src/gen_menu.o \
./Src/gen_preset.o \
./Src/gpio.o \
./Src/lcd.o \
./Src/main.o \
./Src/meas_chip.o \
./Src/menu.o \
./Src/rotary_switch.o \
./Src/scope.o \
./Src/scope_test.o \
./Src/settings.o \
./Src/stm32f4xx_hal_msp.o \
./Src/stm32f4xx_it.o \
./Src/syscalls.o \
./Src/sysmem.o \
./Src/system_stm32f4xx.o \
./Src/tim.o \
./Src/usart.o 

C_DEPS += \
./Src/battery.d \
./Src/beep.d \
./Src/button.d \
./Src/eeprom.d \
./Src/gen.d \
./Src/gen_menu.d \
./Src/gen_preset.d \
./Src/gpio.d \
./Src/lcd.d \
./Src/main.d \
./Src/meas_chip.d \
./Src/menu.d \
./Src/rotary_switch.d \
./Src/scope.d \
./Src/scope_test.d \
./Src/settings.d \
./Src/stm32f4xx_hal_msp.d \
./Src/stm32f4xx_it.d \
./Src/syscalls.d \
./Src/sysmem.d \
./Src/system_stm32f4xx.d \
./Src/tim.d \
./Src/usart.d 


# Each subdirectory must supply rules for building sources it contributes
Src/%.o Src/%.su Src/%.cyclo: ../Src/%.c Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F410Rx -c -I../Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Src

clean-Src:
	-$(RM) ./Src/battery.cyclo ./Src/battery.d ./Src/battery.o ./Src/battery.su ./Src/beep.cyclo ./Src/beep.d ./Src/beep.o ./Src/beep.su ./Src/button.cyclo ./Src/button.d ./Src/button.o ./Src/button.su ./Src/eeprom.cyclo ./Src/eeprom.d ./Src/eeprom.o ./Src/eeprom.su ./Src/gen.cyclo ./Src/gen.d ./Src/gen.o ./Src/gen.su ./Src/gen_menu.cyclo ./Src/gen_menu.d ./Src/gen_menu.o ./Src/gen_menu.su ./Src/gen_preset.cyclo ./Src/gen_preset.d ./Src/gen_preset.o ./Src/gen_preset.su ./Src/gpio.cyclo ./Src/gpio.d ./Src/gpio.o ./Src/gpio.su ./Src/lcd.cyclo ./Src/lcd.d ./Src/lcd.o ./Src/lcd.su ./Src/main.cyclo ./Src/main.d ./Src/main.o ./Src/main.su ./Src/meas_chip.cyclo ./Src/meas_chip.d ./Src/meas_chip.o ./Src/meas_chip.su ./Src/menu.cyclo ./Src/menu.d ./Src/menu.o ./Src/menu.su ./Src/rotary_switch.cyclo ./Src/rotary_switch.d ./Src/rotary_switch.o ./Src/rotary_switch.su ./Src/scope.cyclo ./Src/scope.d ./Src/scope.o ./Src/scope.su ./Src/scope_test.cyclo ./Src/scope_test.d ./Src/scope_test.o ./Src/scope_test.su ./Src/settings.cyclo ./Src/settings.d ./Src/settings.o ./Src/settings.su ./Src/stm32f4xx_hal_msp.cyclo ./Src/stm32f4xx_hal_msp.d ./Src/stm32f4xx_hal_msp.o ./Src/stm32f4xx_hal_msp.su ./Src/stm32f4xx_it.cyclo ./Src/stm32f4xx_it.d ./Src/stm32f4xx_it.o ./Src/stm32f4xx_it.su ./Src/syscalls.cyclo ./Src/syscalls.d ./Src/syscalls.o ./Src/syscalls.su ./Src/sysmem.cyclo ./Src/sysmem.d ./Src/sysmem.o ./Src/sysmem.su ./Src/system_stm32f4xx.cyclo ./Src/system_stm32f4xx.d ./Src/system_stm32f4xx.o ./Src/system_stm32f4xx.su ./Src/tim.cyclo ./Src/tim.d ./Src/tim.o ./Src/tim.su ./Src/usart.cyclo ./Src/usart.d ./Src/usart.o ./Src/usart.su

.PHONY: clean-Src

