/*
 * settings.c
 *
 *  Užívateľské nastavenia v EEPROM (viď eeprom_map.h):
 *    kópia A na 0x0000, kópia B na 0x0040 – každá vo vlastnej stránke.
 *  Zapisuje sa vždy do staršej kópie s vyšším počítadlom (seq). Pri načítaní sa použije
 *  platná kópia s najvyšším seq. Prerušený zápis tak nikdy nezničí obe kópie.
 *  Ak EEPROM neodpovedá alebo obe kópie sú neplatné, použijú sa predvolené hodnoty.
 */

#include <string.h>

#include "settings.h"
#include "eeprom.h"
#include "gen.h"

#define SETTINGS_MAGIC     0x38314447UL      // "GD18"
#define SETTINGS_VERSION   1u

// 32 bajtov – rezerva pre ďalšie nastavenia bez zmeny rozloženia
typedef struct {
    uint32_t magic;
    uint16_t version;
    uint16_t seq;              // počítadlo zápisov (pretečenie sa rieši porovnaním rozdielu)
    uint8_t  auto_off_min;
    uint8_t  auto_reset;
    uint8_t  probe_reset;
    uint8_t  gen_off_min;      // pridané v0.40 – v starších záznamoch 0xFF -> predvolená hodnota
    uint8_t  gen_wave;
    uint8_t  gen_freq;
    uint8_t  gen_duty;
    uint8_t  gen_volt;
    uint8_t  probe_c;          // pridané v0.47 – v starších záznamoch 0xFF -> predvolená hodnota
    uint8_t  probe_va;
    uint8_t  probe_vac;
    uint8_t  quick_rdc;        // pridané v0.48 – 0xFF v starších záznamoch -> OFF
    uint8_t  def_sub;          // pridané v0.49 – 0xFF v starších záznamoch -> všetko DC / odpor / Hz
    uint8_t  gen_auto_on;      // pridané v0.52 – 0xFF v starších záznamoch -> OFF
    uint8_t  gen_on_change;
    uint8_t  gen_cal;          // korekcia + 128 (28..228); 0xFF -> 0
    uint8_t  long_press;       // v0.54: stovky ms 4..14 (v0.53 index 0..10 -> mimo rozsahu -> 500 ms)
    uint8_t  beep;             // pridané v0.54 – 0xFF -> ON
    uint8_t  battery_cap;      // pridané v0.54 – stovky mAh 20..35; 0xFF -> 2200 mAh
    uint8_t  start_bl;         // pridané v0.55 – 0..2; 0xFF -> 50 % (záznam je teraz plný)
    uint32_t crc;              // CRC-32 cez všetky predchádzajúce bajty
} Record_t;

_Static_assert(sizeof(Record_t) == 32, "Record_t musi mat 32 B");

AppSettings_t g_settings;

static const AppSettings_t defaults = {
    .auto_off_min = 10,          // predvolený čas po nahratí firmvéru / prázdnej EEPROM
    .auto_reset   = true,
    .probe_reset  = true,
    .probe_c      = 1,           // 100 pF (ako pevný prah do v0.46)
    .probe_va     = 0,           // OFF
    .probe_vac    = 0,           // OFF
    .quick_rdc    = false,
    .def_sub      = 0,           // DC, odpor, Hz
    .gen_auto_on  = false,
    .gen_on_change = false,
    .gen_cal      = 0,
    .long_press   = 5,           // 500 ms
    .beep         = true,
    .battery_cap  = 22,          // 2200 mAh
    .start_bl     = 1,           // 50 %
    .gen_off_min  = 30,
    .gen_wave     = GEN_WAVE_SINE,
    .gen_freq     = 3,           // 1 kHz
    .gen_duty     = 4,           // 50 %
    .gen_volt     = 10,          // 3.0 Vpp
};

// Položka zo záznamu, alebo predvolená hodnota, ak je mimo rozsahu (napr. 0xFF zo starej verzie)
static uint8_t Field(uint8_t v, uint8_t max, uint8_t def) {
    return (v <= max) ? v : def;
}

static uint16_t last_seq   = 0;
static int8_t   last_slot  = -1;   // 0 = A, 1 = B, -1 = žiadna platná kópia
static Record_t last_rec;          // posledný uložený obsah (na zistenie zmien)

static uint32_t Crc32(const uint8_t *p, uint32_t n) {
    uint32_t crc = 0xFFFFFFFFUL;
    while (n--) {
        crc ^= *p++;
        for (int k = 0; k < 8; k++) {
            crc = (crc & 1u) ? (crc >> 1) ^ 0xEDB88320UL : (crc >> 1);
        }
    }
    return ~crc;
}

static bool RecordValid(const Record_t *r) {
    return r->magic == SETTINGS_MAGIC &&
           r->version == SETTINGS_VERSION &&
           r->crc == Crc32((const uint8_t *)r, sizeof(Record_t) - 4) &&
           r->auto_off_min >= SETTINGS_AUTO_OFF_MIN_MIN &&
           r->auto_off_min <= SETTINGS_AUTO_OFF_MIN_MAX &&
           r->auto_reset <= 1 && r->probe_reset <= 1;
}

static uint16_t SlotAddr(int slot) {
    return (slot == 0) ? EE_SETTINGS_A_ADDR : EE_SETTINGS_B_ADDR;
}

void Settings_Load(void) {
    g_settings = defaults;
    last_slot  = -1;
    last_seq   = 0;

    Record_t r[2];
    bool ok[2];
    for (int s = 0; s < 2; s++) {
        ok[s] = EEPROM_Read(SlotAddr(s), (uint8_t *)&r[s], sizeof(Record_t)) && RecordValid(&r[s]);
    }

    int best = -1;
    if (ok[0] && ok[1]) {
        // novšia = tá, ktorej seq je "pred" druhou (funguje aj po pretečení 65535 -> 0)
        best = ((int16_t)(r[1].seq - r[0].seq) > 0) ? 1 : 0;
    } else if (ok[0]) {
        best = 0;
    } else if (ok[1]) {
        best = 1;
    }

    if (best >= 0) {
        last_slot = (int8_t)best;
        last_seq  = r[best].seq;
        last_rec  = r[best];
        g_settings.auto_off_min = r[best].auto_off_min;
        g_settings.auto_reset   = r[best].auto_reset != 0;
        g_settings.probe_reset  = r[best].probe_reset != 0;
        g_settings.probe_c      = Field(r[best].probe_c,   SETTINGS_PROBE_C_MAX,   defaults.probe_c);
        g_settings.probe_va     = Field(r[best].probe_va,  SETTINGS_PROBE_VA_MAX,  defaults.probe_va);
        g_settings.probe_vac    = Field(r[best].probe_vac, SETTINGS_PROBE_VAC_MAX, defaults.probe_vac);
        g_settings.quick_rdc    = (r[best].quick_rdc == 1);
        uint8_t ds = r[best].def_sub;            // 0xFF = nezapísané; Ω 3 = neplatné -> odpor
        if (ds == 0xFF) ds = defaults.def_sub;
        if (((ds >> SETTINGS_DEF_OHM) & 3u) == 3u) ds &= (uint8_t)~(3u << SETTINGS_DEF_OHM);
        g_settings.def_sub      = ds;
        g_settings.gen_auto_on  = (r[best].gen_auto_on == 1);
        g_settings.gen_on_change = (r[best].gen_on_change == 1);
        uint8_t lp = r[best].long_press;
        g_settings.long_press   = (lp >= SETTINGS_LONG_PRESS_MIN && lp <= SETTINGS_LONG_PRESS_MAX) ? lp : defaults.long_press;
        g_settings.beep         = (r[best].beep != 0);          // 0xFF (starší záznam) = ON
        uint8_t bc = r[best].battery_cap;
        g_settings.battery_cap  = (bc >= SETTINGS_BAT_CAP_MIN && bc <= SETTINGS_BAT_CAP_MAX) ? bc : defaults.battery_cap;
        g_settings.start_bl     = Field(r[best].start_bl, SETTINGS_START_BL_MAX, defaults.start_bl);
        uint8_t gc = r[best].gen_cal;
        g_settings.gen_cal = (gc >= 128u - SETTINGS_GEN_CAL_MAX && gc <= 128u + SETTINGS_GEN_CAL_MAX)
                             ? (int8_t)((int)gc - 128) : 0;
        uint8_t go = r[best].gen_off_min;
        g_settings.gen_off_min  = (go <= SETTINGS_GEN_OFF_MAX && go % SETTINGS_GEN_OFF_STEP == 0) ? go : defaults.gen_off_min;
        g_settings.gen_wave     = Field(r[best].gen_wave, GEN_WAVE_COUNT - 1, defaults.gen_wave);
        g_settings.gen_freq     = Field(r[best].gen_freq, GEN_NUM_FREQ - 1,   defaults.gen_freq);
        g_settings.gen_duty     = Field(r[best].gen_duty, GEN_NUM_DUTY - 1,   defaults.gen_duty);
        g_settings.gen_volt     = Field(r[best].gen_volt, GEN_NUM_VOLT - 1,   defaults.gen_volt);
    }
}

bool Settings_Save(void) {
    // Nič sa nezmenilo -> nezapisovať
    if (last_slot >= 0 &&
        last_rec.auto_off_min == g_settings.auto_off_min &&
        last_rec.auto_reset   == (g_settings.auto_reset ? 1 : 0) &&
        last_rec.probe_reset  == (g_settings.probe_reset ? 1 : 0) &&
        last_rec.probe_c      == g_settings.probe_c &&
        last_rec.probe_va     == g_settings.probe_va &&
        last_rec.probe_vac    == g_settings.probe_vac &&
        last_rec.quick_rdc    == (g_settings.quick_rdc ? 1 : 0) &&
        last_rec.def_sub      == g_settings.def_sub &&
        last_rec.gen_auto_on  == (g_settings.gen_auto_on ? 1 : 0) &&
        last_rec.gen_on_change == (g_settings.gen_on_change ? 1 : 0) &&
        last_rec.gen_cal      == (uint8_t)(g_settings.gen_cal + 128) &&
        last_rec.long_press   == g_settings.long_press &&
        last_rec.beep         == (g_settings.beep ? 1 : 0) &&
        last_rec.battery_cap  == g_settings.battery_cap &&
        last_rec.start_bl     == g_settings.start_bl &&
        last_rec.gen_off_min  == g_settings.gen_off_min &&
        last_rec.gen_wave     == g_settings.gen_wave &&
        last_rec.gen_freq     == g_settings.gen_freq &&
        last_rec.gen_duty     == g_settings.gen_duty &&
        last_rec.gen_volt     == g_settings.gen_volt) {
        return true;
    }

    Record_t rec;
    memset(&rec, 0xFF, sizeof(rec));
    rec.magic        = SETTINGS_MAGIC;
    rec.version      = SETTINGS_VERSION;
    rec.seq          = (uint16_t)(last_seq + 1u);
    rec.auto_off_min = g_settings.auto_off_min;
    rec.auto_reset   = g_settings.auto_reset ? 1 : 0;
    rec.probe_reset  = g_settings.probe_reset ? 1 : 0;
    rec.probe_c      = g_settings.probe_c;
    rec.probe_va     = g_settings.probe_va;
    rec.probe_vac    = g_settings.probe_vac;
    rec.quick_rdc    = g_settings.quick_rdc ? 1 : 0;
    rec.def_sub      = g_settings.def_sub;
    rec.gen_auto_on  = g_settings.gen_auto_on ? 1 : 0;
    rec.gen_on_change = g_settings.gen_on_change ? 1 : 0;
    rec.gen_cal      = (uint8_t)(g_settings.gen_cal + 128);
    rec.long_press   = g_settings.long_press;
    rec.beep         = g_settings.beep ? 1 : 0;
    rec.battery_cap  = g_settings.battery_cap;
    rec.start_bl     = g_settings.start_bl;
    rec.gen_off_min  = g_settings.gen_off_min;
    rec.gen_wave     = g_settings.gen_wave;
    rec.gen_freq     = g_settings.gen_freq;
    rec.gen_duty     = g_settings.gen_duty;
    rec.gen_volt     = g_settings.gen_volt;
    rec.crc          = Crc32((const uint8_t *)&rec, sizeof(Record_t) - 4);

    int slot = (last_slot == 0) ? 1 : 0;            // vždy prepísať tú staršiu kópiu
    if (!EEPROM_Write(SlotAddr(slot), (const uint8_t *)&rec, sizeof(rec))) return false;

    // Kontrola spätným čítaním
    Record_t chk;
    if (!EEPROM_Read(SlotAddr(slot), (uint8_t *)&chk, sizeof(chk)) ||
        memcmp(&chk, &rec, sizeof(rec)) != 0) {
        return false;
    }

    last_slot = (int8_t)slot;
    last_seq  = rec.seq;
    last_rec  = rec;
    return true;
}

// ---------------------------------------------------------------------------
// Posledné nastavenie generátora (stav výstupu ON/OFF sa neukladá)
// ---------------------------------------------------------------------------
void Settings_GenToRam(void) {
    g_gen.wave     = g_settings.gen_wave;
    g_gen.freq_idx = g_settings.gen_freq;
    g_gen.duty_idx = g_settings.gen_duty;
    g_gen.volt_idx = g_settings.gen_volt;
    if (g_gen.freq_idx >= Gen_FreqCount(g_gen.wave)) g_gen.freq_idx = Gen_FreqCount(g_gen.wave) - 1u;
}

bool Settings_GenSave(void) {
    g_settings.gen_wave = g_gen.wave;
    g_settings.gen_freq = g_gen.freq_idx;
    g_settings.gen_duty = g_gen.duty_idx;
    g_settings.gen_volt = g_gen.volt_idx;
    return Settings_Save();              // porovná s posledným záznamom, pri zhode nič nezapíše
}
