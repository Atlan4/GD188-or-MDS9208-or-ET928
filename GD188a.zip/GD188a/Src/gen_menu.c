/*
 * gen_menu.c
 *
 *  Obrazovka generátora:
 *
 *    hlavné ovládanie:  F1 WAVE   F2 FREQ   F3 DUTY   F4 VOLT   -> otvorí zoznam hodnôt
 *    v zozname:         F1 EXIT   F2 dole   F3 hore             (výber platí hneď)
 *    SAVE:              výstup ON / OFF
 *    dlhé BL:           odchod z generátora (rieši main.c)
 *
 *  Rozloženie: vľavo parametre, vpravo náhľad tvaru vlny (zoznam hodnôt sa otvára na jeho mieste),
 *  pod parametrami stav výstupu a nápoveda. Horný riadok (čas, nadpis, batéria) kreslí main.c.
 */

#include <stdio.h>
#include <string.h>

#include "gen_menu.h"
#include "gen.h"
#include "lcd.h"

// --- Rozloženie ---
#define PAR_X        8
#define PAR_VAL_X    (PAR_X + 5 * 12)       // hodnota za "WAVE "
#define PAR_Y0       44
#define PAR_STEP     26
#define PAR_VAL_LEN  8                      // znakov hodnoty (vrátane medzier)

#define OUT_Y        152
#define HINT_Y       178

#define PV_X         176                    // náhľad vlny (rámik)
#define PV_Y         40
#define PV_W         136
#define PV_H         96

#define POP_X        176                    // zoznam hodnôt (na mieste náhľadu)
#define POP_Y        36
#define POP_W        136
#define POP_H        164
#define POP_ROWS     7
#define POP_ROW_Y    42
#define POP_ROW_H    22

#define REPEAT_DELAY_MS   400
#define REPEAT_PERIOD_MS  150

typedef enum { PAR_WAVE = 0, PAR_FREQ, PAR_DUTY, PAR_VOLT, PAR_NONE = 0xFF } Param_t;

static Param_t      popup = PAR_NONE;       // práve otvorený zoznam
static ButtonType_t rep_btn = BTN_NONE;
static uint32_t     rep_tick;

// Cache prekresľovania
static char     last_par[4][24];
static int8_t   last_out = -1;
static char     last_pv[16];
static char     last_cells[4][8];
static char     last_pop[POP_ROWS][16];
static uint8_t  last_pop_top = 0xFF;

// ---------------------------------------------------------------------------
static uint8_t ParCount(Param_t p) {
    switch (p) {
        case PAR_WAVE: return GEN_WAVE_COUNT;
        case PAR_FREQ: return Gen_FreqCount(g_gen.wave);
        case PAR_DUTY: return GEN_NUM_DUTY;
        case PAR_VOLT: return GEN_NUM_VOLT;
        default:       return 0;
    }
}

static uint8_t *ParIdx(Param_t p) {
    switch (p) {
        case PAR_WAVE: return &g_gen.wave;
        case PAR_FREQ: return &g_gen.freq_idx;
        case PAR_DUTY: return &g_gen.duty_idx;
        default:       return &g_gen.volt_idx;
    }
}

// Číselné zoznamy sa zobrazujú od najväčšej hodnoty hore (UP = vyššia hodnota),
// tvar vlny v prirodzenom poradí. Poloha = riadok v zozname (0 = hore).
static bool ParReversed(Param_t p) { return p != PAR_WAVE; }
static uint8_t PosToIdx(Param_t p, uint8_t pos) {
    return ParReversed(p) ? (uint8_t)(ParCount(p) - 1u - pos) : pos;
}
#define IdxToPos PosToIdx      // zobrazenie je symetrické

// Text hodnoty pre položku idx daného parametra
static void ValueText(Param_t p, uint8_t idx, char *buf, size_t n) {
    switch (p) {
        case PAR_WAVE: snprintf(buf, n, "%s", Gen_WaveName(idx)); break;
        case PAR_FREQ: Gen_FormatFreq(Gen_FreqHz(idx), buf, n); break;
        case PAR_DUTY: snprintf(buf, n, "%u %%", Gen_DutyPct(idx)); break;
        default:       Gen_FormatVolt(Gen_VoltMv(idx), buf, n); break;
    }
}

static void DrawCell(uint8_t idx, const char *txt, uint16_t fg, uint16_t bg) {
    char key[8];
    snprintf(key, sizeof(key), "%.5s%c", txt, (fg == LCD_WHITE) ? 'w' : (fg == LCD_GREY) ? 'g' : 'c');
    if (strcmp(key, last_cells[idx]) == 0) return;
    strcpy(last_cells[idx], key);
    LCD_DrawMenuCell(idx, txt, fg, bg);
}

// ---------------------------------------------------------------------------
// Parametre vľavo
// ---------------------------------------------------------------------------
static void DrawParams(void) {
    static const char *const labels[4] = { "WAVE", "FREQ", "DUTY", "VOLT" };
    for (uint8_t p = 0; p < 4; p++) {
        char val[16], line[16], key[24];
        bool dimmed = (p == PAR_DUTY && !Gen_DutyUsed(g_gen.wave));
        if (dimmed) strcpy(val, "--");
        else        ValueText((Param_t)p, *ParIdx((Param_t)p), val, sizeof(val));
        snprintf(line, sizeof(line), "%-*.*s", PAR_VAL_LEN, PAR_VAL_LEN, val);

        bool edit = (popup == (Param_t)p);
        snprintf(key, sizeof(key), "%c%c%s", edit ? 'E' : '-', dimmed ? 'D' : '-', line);
        if (strcmp(key, last_par[p]) == 0) continue;
        strcpy(last_par[p], key);

        uint16_t y = PAR_Y0 + p * PAR_STEP;
        LCD_DrawString(PAR_X, y, labels[p], dimmed ? LCD_GREY : LCD_WHITE, LCD_BLACK, 2);
        LCD_DrawString(PAR_VAL_X, y, line, dimmed ? LCD_GREY : LCD_YELLOW, LCD_BLACK, 2);

        // Rámik okolo hodnoty, ktorá sa práve nastavuje (inak rámik zmazať)
        uint16_t fc = edit ? LCD_SEL_BG : LCD_BLACK;
        const uint16_t fx = PAR_VAL_X - 4, fy = y - 4;
        const uint16_t fw = PAR_VAL_LEN * 12 + 6, fh = 16 + 7;
        LCD_DrawFastHLine(fx, fy, fw, fc);
        LCD_DrawFastHLine(fx, fy + fh - 1, fw, fc);
        LCD_DrawFastVLine(fx, fy, fh, fc);
        LCD_DrawFastVLine(fx + fw - 1, fy, fh, fc);
    }
}

// ---------------------------------------------------------------------------
// Stav výstupu a nápoveda
// ---------------------------------------------------------------------------
static void DrawOutput(void) {
    int8_t on = g_gen.on ? 1 : 0;
    if (on == last_out) return;
    last_out = on;
    LCD_FillRect(PAR_X, OUT_Y, 160, 16, LCD_BLACK);
    LCD_DrawString(PAR_X, OUT_Y, "OUTPUT", LCD_WHITE, LCD_BLACK, 2);
    if (on) LCD_DrawString(PAR_X + 7 * 12, OUT_Y, "ON",  LCD_GREEN, LCD_BLACK, 2);
    else    LCD_DrawString(PAR_X + 7 * 12, OUT_Y, "OFF", LCD_RED,   LCD_BLACK, 2);
}

static void DrawHints(void) {
    // Ovládanie výstupu tlačidlom SAVE nie je zvyčajné -> vždy napísané na obrazovke
    LCD_DrawString(PAR_X, HINT_Y,      "SAVE    = output ON/OFF", LCD_LIGHTGREY, LCD_BLACK, 1);
    LCD_DrawString(PAR_X, HINT_Y + 12, "Hold BL = exit",          LCD_LIGHTGREY, LCD_BLACK, 1);
}

// ---------------------------------------------------------------------------
// Náhľad tvaru vlny (2 periódy). Výška podľa amplitúdy, sivá pri vypnutom výstupe.
// ---------------------------------------------------------------------------
static void DrawPreview(bool force) {
    if (popup != PAR_NONE) return;
    char key[16];
    snprintf(key, sizeof(key), "%u%u%u%u", g_gen.wave, g_gen.duty_idx, g_gen.volt_idx, g_gen.on ? 1 : 0);
    if (!force && strcmp(key, last_pv) == 0) return;
    strcpy(last_pv, key);

    const uint16_t ix = PV_X + 2, iy = PV_Y + 2;
    const uint16_t iw = PV_W - 4, ih = PV_H - 4;
    const int16_t  mid = (int16_t)(iy + ih / 2);

    LCD_FillRect(PV_X, PV_Y, PV_W, PV_H, LCD_BLACK);
    LCD_DrawFastHLine(PV_X, PV_Y, PV_W, LCD_GREY);
    LCD_DrawFastHLine(PV_X, PV_Y + PV_H - 1, PV_W, LCD_GREY);
    LCD_DrawFastVLine(PV_X, PV_Y, PV_H, LCD_GREY);
    LCD_DrawFastVLine(PV_X + PV_W - 1, PV_Y, PV_H, LCD_GREY);
    for (uint16_t x = ix; x < ix + iw; x += 4) LCD_DrawPixel(x, (uint16_t)mid, LCD_GREY);  // bodkovaná nula

    uint16_t mv  = Gen_VoltMv(g_gen.volt_idx);
    int32_t  amp = (int32_t)((ih / 2 - 2) * (uint32_t)mv / 3000u);
    if (mv > 0 && amp < 3) amp = 3;
    uint16_t color = g_gen.on ? LCD_YELLOW : LCD_LIGHTGREY;
    uint8_t  duty  = Gen_DutyPct(g_gen.duty_idx);
    uint32_t per   = iw / 2;                         // 2 periódy na šírku

    int16_t prev_y = 0;
    for (uint16_t x = 0; x < iw; x++) {
        int32_t s = Gen_Shape(g_gen.wave, duty, x % per, per);
        int16_t y = (int16_t)(mid - (s * amp) / 32767);
        if (x == 0) prev_y = y;
        // zvislá spojnica s predchádzajúcim bodom (hrany obdĺžnika, strmá rampa)
        int16_t y0 = (prev_y < y) ? prev_y : y;
        int16_t y1 = (prev_y < y) ? y : prev_y;
        LCD_DrawFastVLine(ix + x, (uint16_t)y0, (uint16_t)(y1 - y0 + 1), color);
        prev_y = y;
    }
}

// ---------------------------------------------------------------------------
// Zoznam hodnôt (7 viditeľných riadkov, posúva sa s výberom)
// ---------------------------------------------------------------------------
static void DrawPopup(bool force) {
    if (popup == PAR_NONE) return;
    uint8_t cnt = ParCount(popup);
    uint8_t sel = IdxToPos(popup, *ParIdx(popup));     // poloha vybranej položky v zozname
    uint8_t top = 0;
    if (cnt > POP_ROWS) {
        top = (sel > POP_ROWS / 2) ? (uint8_t)(sel - POP_ROWS / 2) : 0;
        if (top > cnt - POP_ROWS) top = (uint8_t)(cnt - POP_ROWS);
    }

    if (force) {
        LCD_FillRect(POP_X, POP_Y, POP_W, POP_H, LCD_BLACK);
        LCD_DrawFastHLine(POP_X, POP_Y, POP_W, LCD_WHITE);
        LCD_DrawFastHLine(POP_X, POP_Y + POP_H - 1, POP_W, LCD_WHITE);
        LCD_DrawFastVLine(POP_X, POP_Y, POP_H, LCD_WHITE);
        LCD_DrawFastVLine(POP_X + POP_W - 1, POP_Y, POP_H, LCD_WHITE);
        memset(last_pop, 0, sizeof(last_pop));
        last_pop_top = 0xFF;
    }

    for (uint8_t r = 0; r < POP_ROWS; r++) {
        uint8_t idx = (uint8_t)(top + r);              // poloha v zozname
        char txt[16], key[16];
        if (idx < cnt) ValueText(popup, PosToIdx(popup, idx), txt, sizeof(txt));
        else           txt[0] = '\0';
        snprintf(key, sizeof(key), "%c%.13s", (idx == sel) ? '>' : ' ', txt);
        if (strcmp(key, last_pop[r]) == 0) continue;
        strcpy(last_pop[r], key);

        uint16_t y = POP_ROW_Y + r * POP_ROW_H;
        uint16_t bg = (idx == sel && idx < cnt) ? LCD_SEL_BG : LCD_BLACK;
        uint16_t fg = (idx == sel && idx < cnt) ? LCD_SEL_FG : LCD_WHITE;
        LCD_FillRect(POP_X + 4, y, POP_W - 16, POP_ROW_H - 2, bg);
        if (txt[0]) LCD_DrawString(POP_X + 10, y + 3, txt, fg, bg, 2);
    }

    // Značky, že sú ďalšie položky nad / pod viditeľnými
    if (top != last_pop_top) {
        last_pop_top = top;
        LCD_DrawString(POP_X + POP_W - 10, POP_ROW_Y + 2, (top > 0) ? "^" : " ", LCD_WHITE, LCD_BLACK, 1);
        LCD_DrawString(POP_X + POP_W - 10, POP_ROW_Y + (POP_ROWS - 1) * POP_ROW_H + 10,
                       (top + POP_ROWS < cnt) ? "v" : " ", LCD_WHITE, LCD_BLACK, 1);
    }
}

static void ClosePopup(void) {
    if (popup == PAR_NONE) return;
    popup = PAR_NONE;
    rep_btn = BTN_NONE;
    LCD_FillRect(POP_X, POP_Y, POP_W, POP_H, LCD_BLACK);
    DrawPreview(true);
}

static void OpenPopup(Param_t p) {
    if (p == PAR_DUTY && !Gen_DutyUsed(g_gen.wave)) return;   // sínus: strieda sa nepoužíva
    popup = p;
    rep_btn = BTN_NONE;
    DrawPopup(true);
}

// Posun výberu v zozname (dir +1 = o riadok nižšie), zmena platí hneď
static void Step(int8_t dir) {
    uint8_t cnt = ParCount(popup);
    uint8_t *idx = ParIdx(popup);
    uint8_t pos = IdxToPos(popup, *idx);
    if (dir > 0 && pos + 1u < cnt) pos++;
    else if (dir < 0 && pos > 0)   pos--;
    else return;
    *idx = PosToIdx(popup, pos);
    Gen_Update();          // pri zmene tvaru aj obmedzenie frekvencie (100 kHz iba sínus)
}

// ---------------------------------------------------------------------------
void GenMenu_Open(void) {
    popup = PAR_NONE;
    rep_btn = BTN_NONE;
    memset(last_par, 0, sizeof(last_par));
    memset(last_cells, 0, sizeof(last_cells));
    last_pv[0] = '\0';
    last_out = -1;

    LCD_Clear(LCD_BLACK);
    LCD_DrawMenuFrame();
    DrawHints();
    DrawParams();
    DrawOutput();
    DrawPreview(true);
    GenMenu_Task(BTN_NONE);
}

void GenMenu_Close(void) {
    popup = PAR_NONE;
    rep_btn = BTN_NONE;
}

void GenMenu_Task(ButtonType_t ev) {
    uint32_t now = HAL_GetTick();

    if (ev == BTN_SAVE) {
        Gen_SetOutput(!g_gen.on);
    } else if (popup == PAR_NONE) {
        switch (ev) {
            case BTN_F1: OpenPopup(PAR_WAVE); break;
            case BTN_F2: OpenPopup(PAR_FREQ); break;
            case BTN_F3: OpenPopup(PAR_DUTY); break;
            case BTN_F4: OpenPopup(PAR_VOLT); break;
            default: break;
        }
    } else {
        switch (ev) {
            case BTN_F1: ClosePopup(); break;
            case BTN_F2: Step(+1); rep_btn = BTN_F2; rep_tick = now + REPEAT_DELAY_MS; break;
            case BTN_F3: Step(-1); rep_btn = BTN_F3; rep_tick = now + REPEAT_DELAY_MS; break;
            default: break;
        }
    }

    // Opakovanie pri držaní F2 / F3 v zozname
    if (rep_btn != BTN_NONE) {
        if (BUTTON_GetHeld() != rep_btn || popup == PAR_NONE) {
            rep_btn = BTN_NONE;
        } else if ((int32_t)(now - rep_tick) >= 0) {
            Step((rep_btn == BTN_F2) ? +1 : -1);
            rep_tick = now + REPEAT_PERIOD_MS;
        }
    }

    DrawParams();
    DrawOutput();
    DrawPreview(false);
    DrawPopup(false);

    // Spodné políčka
    if (popup == PAR_NONE) {
        DrawCell(0, "WAVE", LCD_WHITE, LCD_BLACK);
        DrawCell(1, "FREQ", LCD_WHITE, LCD_BLACK);
        DrawCell(2, "DUTY", Gen_DutyUsed(g_gen.wave) ? LCD_WHITE : LCD_GREY, LCD_BLACK);
        DrawCell(3, "VOLT", LCD_WHITE, LCD_BLACK);
    } else {
        DrawCell(0, "EXIT", LCD_CYAN,  LCD_BLACK);
        DrawCell(1, "DOWN", LCD_WHITE, LCD_BLACK);
        DrawCell(2, "UP",   LCD_WHITE, LCD_BLACK);
        DrawCell(3, "",     LCD_WHITE, LCD_BLACK);
    }
}
