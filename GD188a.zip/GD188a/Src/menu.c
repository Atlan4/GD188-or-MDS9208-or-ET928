/*
 * menu.c
 *
 *  Menu nastavení:
 *    Auto OFF:          xx:00   F3 -1 min, F4 +1 min (podržanie = opakovanie)
 *    Auto reset time:   ON/OFF  tlačidlá a prepínač reštartujú odpočet
 *    Probe reset:       ON/OFF  v Ω / dióde / pípaku prechod z OL na hodnotu reštartuje odpočet
 *
 *  Texty na displeji sú po anglicky (font 5x7 nemá diakritiku).
 */

#include <stdio.h>
#include <string.h>

#include "menu.h"
#include "lcd.h"
#include "settings.h"
#include "battery.h"

#define MENU_LINES        3
#define LINE_Y0           45
#define LINE_STEP         30
#define TEXT_X            22
#define MARK_X            6
#define HINT_Y            150
#define BAT_INFO_Y        184

#define REPEAT_DELAY_MS   500    // po tomto čase držania sa hodnota začne meniť sama
#define REPEAT_PERIOD_MS  100    // perióda opakovania počas držania

static uint8_t      sel_line;
static AppSettings_t edit;           // upravované hodnoty (do flash až pri EXIT)
static ButtonType_t rep_btn;
static uint32_t     rep_tick;

// Cache pre prekresľovanie iba zmien
static char         last_line[MENU_LINES][32];
static char         last_cells[4][8];
static uint8_t      last_hint_line;
static uint16_t     last_bat_mv;

static const char *const hints[MENU_LINES][2] = {
    { "Time until automatic power off (1 - 99 min).",
      "Hold F3 / F4 to change the value faster." },
    { "ON: every button press or rotary switch turn",
      "restarts the countdown from the beginning." },
    { "ON: in R / diode / continuity / capacitance",
      "mode, probe contact restarts the countdown." },
};

static void LineText(uint8_t i, char *buf, size_t n) {
    char val[8];
    const char *label = "";
    switch (i) {
        case 0: label = "Auto OFF:";        snprintf(val, sizeof(val), "%02u:00", edit.auto_off_min); break;
        case 1: label = "Auto reset time:"; snprintf(val, sizeof(val), "%s", edit.auto_reset  ? "ON" : "OFF"); break;
        default:label = "Probe reset:";     snprintf(val, sizeof(val), "%s", edit.probe_reset ? "ON" : "OFF"); break;
    }
    snprintf(buf, n, "%-17s%7s", label, val);
}

static void DrawCell(uint8_t idx, const char *txt, uint16_t fg, uint16_t bg) {
    // Kľúč cache obsahuje aj farbu pozadia, aby sa prekreslilo pri zmene zvýraznenia
    char key[8];
    snprintf(key, sizeof(key), "%.5s%c", txt, (bg == LCD_BLACK) ? '0' : (bg == LCD_YELLOW) ? '1' : '2');
    if (strcmp(key, last_cells[idx]) == 0) return;
    strcpy(last_cells[idx], key);
    LCD_DrawMenuCell(idx, txt, fg, bg);
}

static void Redraw(void) {
    ButtonType_t held = BUTTON_GetHeld();

    // Riadky nastavení: vybraný žltý so šípkou
    for (uint8_t i = 0; i < MENU_LINES; i++) {
        char buf[28];
        LineText(i, buf, sizeof(buf));
        buf[25] = '\0';
        char key[32];
        snprintf(key, sizeof(key), "%c%s", (i == sel_line) ? '>' : ' ', buf);
        if (strcmp(key, last_line[i]) == 0) continue;
        strcpy(last_line[i], key);

        uint16_t y = LINE_Y0 + i * LINE_STEP;
        uint16_t color = (i == sel_line) ? LCD_YELLOW : LCD_WHITE;
        LCD_DrawString(MARK_X, y, (i == sel_line) ? ">" : " ", LCD_YELLOW, LCD_BLACK, 2);
        LCD_DrawString(TEXT_X, y, buf, color, LCD_BLACK, 2);
    }

    // Nápoveda k vybranému riadku (malé písmo)
    if (last_hint_line != sel_line) {
        last_hint_line = sel_line;
        LCD_FillRect(2, HINT_Y, 316, 24, LCD_BLACK);
        LCD_DrawString(10, HINT_Y,      hints[sel_line][0], LCD_LIGHTGREY, LCD_BLACK, 1);
        LCD_DrawString(10, HINT_Y + 12, hints[sel_line][1], LCD_LIGHTGREY, LCD_BLACK, 1);
    }

    // Informácia: napätie batérie (na kontrolu merania)
    uint16_t mv = Battery_GetMillivolts();
    if (mv != last_bat_mv) {
        last_bat_mv = mv;
        char b[48];
        snprintf(b, sizeof(b), "Battery voltage: %u.%02u V  (%u %%)",
                 mv / 1000u, (mv % 1000u) / 10u, Battery_GetPercent());
        LCD_FillRect(2, BAT_INFO_Y, 316, 10, LCD_BLACK);
        LCD_DrawString(10, BAT_INFO_Y, b, LCD_LIGHTGREY, LCD_BLACK, 1);
    }

    // Spodné políčka s funkciami tlačidiel
    DrawCell(0, "EXIT", LCD_CYAN,  LCD_BLACK);
    DrawCell(1, "NEXT", LCD_WHITE, LCD_BLACK);
    if (sel_line == 0) {
        // - / + : žlté pozadie, kým je tlačidlo držané
        if (held == BTN_F3) DrawCell(2, "-", LCD_BLACK,  LCD_YELLOW);
        else                DrawCell(2, "-", LCD_YELLOW, LCD_BLACK);
        if (held == BTN_F4) DrawCell(3, "+", LCD_BLACK,  LCD_YELLOW);
        else                DrawCell(3, "+", LCD_YELLOW, LCD_BLACK);
    } else {
        // OFF / ON : aktívna voľba má zelené pozadie (ako Hz / DUTY)
        bool on = (sel_line == 1) ? edit.auto_reset : edit.probe_reset;
        if (on) { DrawCell(2, "OFF", LCD_WHITE,  LCD_BLACK);  DrawCell(3, "ON", LCD_SEL_FG, LCD_SEL_BG); }
        else    { DrawCell(2, "OFF", LCD_SEL_FG, LCD_SEL_BG); DrawCell(3, "ON", LCD_WHITE,  LCD_BLACK);  }
    }
}

static void Adjust(ButtonType_t b) {
    switch (sel_line) {
        case 0:
            if (b == BTN_F3 && edit.auto_off_min > SETTINGS_AUTO_OFF_MIN_MIN) edit.auto_off_min--;
            if (b == BTN_F4 && edit.auto_off_min < SETTINGS_AUTO_OFF_MIN_MAX) edit.auto_off_min++;
            break;
        case 1: edit.auto_reset  = (b == BTN_F4); break;
        case 2: edit.probe_reset = (b == BTN_F4); break;
        default: break;
    }
}

void Menu_Open(void) {
    edit = g_settings;
    sel_line = 0;
    rep_btn = BTN_NONE;
    memset(last_line, 0, sizeof(last_line));
    memset(last_cells, 0, sizeof(last_cells));
    last_hint_line = 0xFF;
    last_bat_mv = 0xFFFF;

    LCD_Clear(LCD_BLACK);

    // Biely rámik okolo celého displeja
    LCD_DrawFastHLine(0, 0, 320, LCD_WHITE);
    LCD_DrawFastHLine(0, 239, 320, LCD_WHITE);
    LCD_DrawFastVLine(0, 0, 240, LCD_WHITE);
    LCD_DrawFastVLine(319, 0, 240, LCD_WHITE);

    // Nadpis a deliaca čiara
    LCD_DrawString((320 - (4 * 12 - 2)) / 2, 8, "MENU", LCD_CYAN, LCD_BLACK, 2);
    LCD_DrawFastHLine(0, 30, 320, LCD_WHITE);

    LCD_DrawMenuFrame();
    Redraw();
}

bool Menu_Task(ButtonType_t ev) {
    uint32_t now = HAL_GetTick();

    switch (ev) {
        case BTN_F1:                                   // EXIT + uloženie
            g_settings = edit;
            Settings_Save();                           // zapíše iba ak sa niečo zmenilo
            return false;

        case BTN_F2:                                   // ďalší riadok dokola
            sel_line = (uint8_t)((sel_line + 1) % MENU_LINES);
            break;

        case BTN_F3:
        case BTN_F4:
            Adjust(ev);
            rep_btn  = ev;
            rep_tick = now + REPEAT_DELAY_MS;
            break;

        default:
            break;
    }

    // Opakovanie počas držania F3 / F4
    ButtonType_t held = BUTTON_GetHeld();
    if (rep_btn != BTN_NONE) {
        if (held != rep_btn) {
            rep_btn = BTN_NONE;
        } else if ((int32_t)(now - rep_tick) >= 0) {
            Adjust(rep_btn);
            rep_tick = now + REPEAT_PERIOD_MS;
        }
    }

    Redraw();
    return true;
}
