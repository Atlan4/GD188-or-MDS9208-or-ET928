/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include <string.h>
#include <stdio.h>

#include "lcd.h"   
#include "meas_chip.h"
#include "rotary_switch.h"
#include "button.h"
#include "settings.h"
#include "eeprom.h"
#include "battery.h"
#include "menu.h"
#include "gen.h"
#include "gen_menu.h"


/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

// Ladiaca obrazovka: 1 = stavový riadok (STATUS: ...) a RAW sniffer bajtov z čipu,
//                    0 = bežná prevádzka (nadpis veličiny hore)
#define DEBUG_SCREEN  0

// Pri Cx malý riadok so surovými dátami z čipu (hodnota a bajt rozsahu) – na overenie
// rozsahov kapacity. 1 = zobraziť, 0 = vypnuté.
#define CX_RAW_INFO   0

// --- Automatické vypnutie ---
// Čas sa nastavuje v menu (g_settings.auto_off_min). Odpočet reštartuje tlačidlo / prepínač
// (ak je zapnuté "Auto reset time") a prechod z OL na hodnotu v Ω / dióde / pípaku
// (ak je zapnuté "Probe reset").
// V generátore (a neskôr osciloskope) platí samostatný čas g_settings.gen_off_min, 0 = OFF.
static uint32_t last_activity_tick = 0;
static bool     auto_off_done = false;

// Dlhé stlačenie F1 otvára menu, krátke = REL (vykoná sa pri pustení)
#define F1_LONG_PRESS_MS  1000
static bool     f1_pending = false;
static uint32_t f1_tick = 0;
static bool     menu_open = false;

// V menu odpočet automatického vypnutia stojí. Po MENU_IDLE_MS bez dotyku menu
// samo skončí (s uložením, ako EXIT) a začne bežný odpočet.
#define MENU_IDLE_MS      (2u * 60u * 1000u)
static uint32_t menu_input_tick = 0;

// Tlačidlo podsvietenia: krátke stlačenie = jas (pri pustení), dlhé = generátor (iba v polohe V)
#define BL_LONG_PRESS_MS  1000
static bool     bl_pending = false;
static uint32_t bl_tick = 0;
static bool     gen_open = false;          // obrazovka generátora
static uint32_t gen_hint_until = 0;        // do tohto času nadpis "GEN: SWITCH TO V"
#define GEN_HINT_MS       2000
static bool     gen_resume = false;        // výstup bol zapnutý pri odchode z polohy V -> po návrate zapnúť
static uint32_t gen_beep_tick = 0;         // pri vypnutom auto-vypnutí pípnutie každých 5 min
#define GEN_BEEP_PERIOD_MS  (5u * 60u * 1000u)

// Odpočet pre aktuálny režim v sekundách, 0 = automatické vypnutie zakázané
static uint32_t AutoOffSeconds(void) {
    if (gen_open) return (uint32_t)g_settings.gen_off_min * 60u;
    return (uint32_t)g_settings.auto_off_min * 60u;
}

// Nastavenie generátora: EEPROM (g_settings) <-> generátor (g_gen). Stav výstupu sa neukladá.
static void Gen_LoadSettings(void) {
    g_gen.wave     = g_settings.gen_wave;
    g_gen.freq_idx = g_settings.gen_freq;
    g_gen.duty_idx = g_settings.gen_duty;
    g_gen.volt_idx = g_settings.gen_volt;
}
// Uloží do EEPROM iba ak sa niečo zmenilo (Settings_Save porovnáva s posledným záznamom)
static void Gen_SaveSettings(void) {
    g_settings.gen_wave = g_gen.wave;
    g_settings.gen_freq = g_gen.freq_idx;
    g_settings.gen_duty = g_gen.duty_idx;
    g_settings.gen_volt = g_gen.volt_idx;
    Settings_Save();
}

// Krátke pípnutie. Bzučiak je aktívny (overené: trvalá log. 1 na PB10 = pípa).
static void Beep(uint32_t ms) {
    HAL_GPIO_WritePin(Buzzer_GPIO_Port, Buzzer_Pin, GPIO_PIN_SET);
    HAL_Delay(ms);
    HAL_GPIO_WritePin(Buzzer_GPIO_Port, Buzzer_Pin, GPIO_PIN_RESET);
}

// Zvýši sa pri návrate z menu -> všetky prvky obrazovky sa prekreslia
static uint32_t screen_epoch = 1;
static uint32_t mode_epoch   = 1;      // zvýši sa pri každej zmene módu (pre Probe reset)

static void NoteActivity(void) {
    if (g_settings.auto_reset) last_activity_tick = HAL_GetTick();
}


uint8_t rx_byte;

#if DEBUG_SCREEN
// --- Debug sniffer (posledných 16 bajtov z čipu) – zapisuje RX prerušenie ---
static volatile uint8_t  debug_rx_buffer[16];
static volatile uint8_t  debug_rx_index = 0;
static volatile uint32_t debug_rx_count = 0;
#endif

// HOLD – číta ho aj LCD_DrawBottomMenu() v lcd.c
volatile bool is_hold_active = false;

// --- Stav prístroja (iba hlavná slučka, ISR sa ich nedotýka) ---
static SwitchPosition_t cur_pos      = SWITCH_POS_V;
static SubMode_t        cur_sub      = SUB_MODE_DC;
static bool             menu_dirty   = true;
static int8_t           pressed_cell = -1;          // políčko menu pod držaným tlačidlom
static ButtonType_t     pending_btn  = BTN_NONE;     // RNG stlačené počas inicializácie čipu

// --- Pamäť nastavení v RAM (platí do vypnutia prístroja) ---
// Pre každú polohu prepínača posledný sub-mód (SEL, Hz/%),
// pre každú kombináciu poloha + sub-mód posledný rozsah (AUTO alebo manuálny rozsah).
#define NUM_POSITIONS  8
#define NUM_SUBMODES   8
static SubMode_t pos_sub[NUM_POSITIONS];
static uint8_t   pos_range[NUM_POSITIONS][NUM_SUBMODES];   // MEAS_RANGE_AUTO alebo číslo rozsahu
static bool             display_dirty = true;   // vynúti prekreslenie jednotiek, bodky aj číslic

// --- Rozsahy ---
// decimals = počet desatinných miest pri 4-miestnom zobrazení (0 = bez bodky)
// exp      = 1 digit tohto rozsahu = 10^exp základných jednotiek polohy.
//            Slúži pre REL: offset sa ukladá v základných jednotkách, takže platí
//            aj keď auto-rozsah medzitým prepne na iný rozsah.
// ol_above = surová hodnota, nad ktorou sa zobrazí OL (0 = bez limitu)
typedef struct {
    uint8_t     decimals;
    uint8_t     exp;
    const char *label;
    const char *unit;
    int32_t     ol_above;
} RangeInfo_t;

// V: základ 0.1 mV
static const RangeInfo_t RANGES_V[]   = { {1, 0, "600.0", "mV"}, {3, 1, "6.000", "V"}, {2, 2, "60.00", "V"},
                                          {1, 3, "600.0", "V"},  {0, 4, "1000",  "V"} };
// mV: základ 0.01 mV
static const RangeInfo_t RANGES_mV[]  = { {2, 0, "60.00", "mV"}, {1, 1, "600.0", "mV"} };
// uA: základ 0.1 uA
static const RangeInfo_t RANGES_uA[]  = { {1, 0, "600.0", "uA"}, {0, 1, "6000",  "uA"} };
// mA: základ 0.01 mA
static const RangeInfo_t RANGES_mA[]  = { {2, 0, "60.00", "mA"}, {1, 1, "600.0", "mA"} };
// 10A: základ 1 mA
static const RangeInfo_t RANGES_10A[] = { {3, 0, "6.000", "A"},  {2, 1, "10.00", "A"} };

// Odpor (58 07): overené na prístroji, 00 = 600 Ω ... 05 = 60 MΩ. "\x7f" = znak Ω vo fonte.
// Základ 0.1 Ω
static const RangeInfo_t RANGES_OHM[] = { {1, 0, "600.0", "\x7f"},  {3, 1, "6.000", "k\x7f"},
                                          {2, 2, "60.00", "k\x7f"}, {1, 3, "600.0", "k\x7f"},
                                          {3, 4, "6.000", "M\x7f"}, {2, 5, "60.00", "M\x7f", 6000} };

// Dióda (58 0A): napätie x.xxx V, naprázdno čip ukazuje ~3237 -> nad 3.200 V = OL
static const RangeInfo_t RANGES_DIODE[] = { {3, 0, "", "V", 3200} };

// Pípak (58 09): iba AUTO 600.0 Ω, nad 600 Ω (rozpojené hroty) = OL
static const RangeInfo_t RANGES_CONT[]  = { {1, 0, "600.0", "\x7f", 6000} };

// Kapacita (58 0B): iba AUTO, základ 1 pF.
// Bajt rozsahu z čipu určuje váhu jedného digitu (overené na prístroji):
//   range 0: 1 pF   (100 nF -> 103325)
//   range 1: 1 nF   (4.7 uF -> 5062)
//   range 2: 10 nF  (210 uF -> 20749)
//   range 3: 1 uF   (3300 uF -> 3357)   – skok o 100x, nie o 10x
//   range 4: 10 uF  (podľa špecifikácie výrobcu, neoverené meraním)
// Tabuľka RANGES_CX_CHIP sa používa len na prepočet hodnoty z čipu na pF.
static const RangeInfo_t RANGES_CX_CHIP[] = { {3, 0, "", "nF"}, {3, 3, "", "uF"},
                                              {2, 4, "", "uF"}, {0, 6, "", "uF"},
                                              {2, 7, "", "mF"} };

// Zobrazovacie rozsahy kapacity – 9999 digitov podľa výrobcu (99.99 nF ... 99.99 mF),
// navyše rozsah "9999 uF", aby sa do 9999 uF ukazovalo v uF (čip má tam krok 1 uF,
// takže sa nič nestráca). exp = 1 digit tohto rozsahu = 10^exp pF.
static const RangeInfo_t RANGES_CAP[] = { {3, 0, "9.999", "nF"},     // jemný rozsah 1 pF (nad rámec výrobcu)
                                          {2, 1, "99.99", "nF"}, {1, 2, "999.9", "nF"},
                                          {3, 3, "9.999", "uF"}, {2, 4, "99.99", "uF"},
                                          {1, 5, "999.9", "uF"}, {0, 6, "9999",  "uF"},
                                          {2, 7, "99.99", "mF"} };

// Hysteréza prepínania rozsahov Cx: nahor hneď keď hodnota prekročí 9999 digitov,
// nadol až keď sa do nižšieho rozsahu zmestí s rezervou (pod 9000 digitov nižšieho rozsahu).
#define CX_DOWN_COUNTS  9000

// Probe reset pri Cx (viď hlavná slučka): prahy v pF a počet potvrdzujúcich meraní
#define CX_PROBE_ON_PF     100     // 0.100 nF – kondenzátor pripojený
#define CX_PROBE_OFF_PF     70     // 0.070 nF – hroty voľné (opätovné "nabitie")
#define CX_PROBE_CONFIRM     2     // koľko meraní po sebe musí byť nad CX_PROBE_ON_PF
static uint8_t cx_disp_range = 0;          // aktuálny zobrazovací rozsah Cx (reset pri zmene módu)


// Formát jednej vzorky pre aktuálnu polohu
typedef struct {
    int8_t      decimals;
    uint8_t     exp;
    const char *label;
    const char *unit;
    const char *acdc;
    uint8_t     icon;        // ikona namiesto AC/DC (ICON_DIODE, ICON_BEEP)
    int32_t     ol_above;
    char        label_buf[8];
} Format_t;

// --- REL (relatívne meranie) ---
static bool         rel_active = false;
static int64_t      rel_offset = 0;          // v základných jednotkách polohy

// REL pre kapacitu sa pamätá aj po otočení prepínača preč a späť (parazitná kapacita káblov).
// Odčítava sa iba v polohe Cx, v ostatných polohách je REL vypnuté.
static bool         cx_rel_active = false;
static int64_t      cx_rel_offset = 0;

// Text korekcie zobrazený nad tlačidlom REL, napr. "-0.050 nF"
static char         rel_text[20] = "";
static char         cx_rel_text[20] = "";
static MeasSample_t last_sample;             // posledná platná vzorka (pre zachytenie REL)
static bool         last_sample_ok = false;
static bool         redraw_last = false;     // prekresliť last_sample (po zapnutí/vypnutí REL)

#define COUNT_OF(a) (sizeof(a) / sizeof((a)[0]))

// --- Rozloženie meracej obrazovky (výškovo) ---
// Horný riadok "AUTO ..." je na y = 45..60, riadok REL korekcie na y = 188..203.
// Veľké číslice (72 px) sú v strede medzi nimi: (61 + 188) / 2 - 36 = 88.
#define DIGITS_Y   88
#define ACDC_Y     (DIGITS_Y + 5)     // AC / DC / ikona vpravo hore pri číslach
#define UNIT_Y     (DIGITS_Y + 55)    // jednotka vpravo dole pri číslach

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

// Rozsahová tabuľka pre polohu a sub-mód (NULL = škálovanie nie je známe)
static const RangeInfo_t *GetRangeTable(SwitchPosition_t pos, SubMode_t sub, uint8_t *count) {
    switch (pos) {
        case SWITCH_POS_OHM_DIODE_CONT:
            if (sub == SUB_MODE_RESISTANCE) { *count = COUNT_OF(RANGES_OHM);   return RANGES_OHM; }
            if (sub == SUB_MODE_DIODE)      { *count = COUNT_OF(RANGES_DIODE); return RANGES_DIODE; }
            if (sub == SUB_MODE_CONTINUITY) { *count = COUNT_OF(RANGES_CONT);  return RANGES_CONT; }
            *count = 0; return NULL;
        case SWITCH_POS_Cx:  *count = COUNT_OF(RANGES_CX_CHIP); return RANGES_CX_CHIP;
        case SWITCH_POS_V:   *count = COUNT_OF(RANGES_V);   return RANGES_V;
        case SWITCH_POS_mV:  *count = COUNT_OF(RANGES_mV);  return RANGES_mV;
        case SWITCH_POS_uA:  *count = COUNT_OF(RANGES_uA);  return RANGES_uA;
        case SWITCH_POS_mA:  *count = COUNT_OF(RANGES_mA);  return RANGES_mA;
        case SWITCH_POS_10A: *count = COUNT_OF(RANGES_10A); return RANGES_10A;
        default:             *count = 0;                    return NULL;
    }
}

// Poloha/sub-mód, kde má zmysel tlačidlo RNG (manuálny rozsah)
static bool HasRangeButton(SwitchPosition_t pos, SubMode_t sub) {
    return pos == SWITCH_POS_V  || pos == SWITCH_POS_mV || pos == SWITCH_POS_uA ||
           pos == SWITCH_POS_mA || pos == SWITCH_POS_10A ||
           (pos == SWITCH_POS_OHM_DIODE_CONT && sub == SUB_MODE_RESISTANCE);
}

// Polohy, kde sa zobrazuje AC/DC
static bool IsVoltCurrentPos(SwitchPosition_t pos) {
    return pos == SWITCH_POS_V  || pos == SWITCH_POS_mV || pos == SWITCH_POS_uA ||
           pos == SWITCH_POS_mA || pos == SWITCH_POS_10A;
}

static int64_t Pow10(uint8_t e) {
    int64_t p = 1;
    while (e--) p *= 10;
    return p;
}

// Delenie so zaokrúhlením na najbližšie celé číslo (aj pre záporné hodnoty)
static int64_t DivRound(int64_t n, int64_t d) {
    return (n >= 0) ? (n + d / 2) / d : -((-n + d / 2) / d);
}

// Výber zobrazovacieho rozsahu pre hodnotu v pF (s hysterézou okolo *state).
// Vráti false, ak je hodnota nad najvyšším rozsahom (OL).
static bool CxSelectRange(int64_t pf, uint8_t *state) {
    int64_t apf = (pf < 0) ? -pf : pf;
    uint8_t r = *state;
    if (r >= COUNT_OF(RANGES_CAP)) r = 0;
    while (r + 1u < COUNT_OF(RANGES_CAP) && DivRound(apf, Pow10(RANGES_CAP[r].exp)) > 9999) r++;
    while (r > 0 && apf < (int64_t)CX_DOWN_COUNTS * Pow10(RANGES_CAP[r - 1].exp)) r--;
    *state = r;
    return DivRound(apf, Pow10(RANGES_CAP[r].exp)) <= 9999;
}

static bool IsAcMode(uint8_t cmd) {
    return cmd == CMD_CHIP_6V_AC || cmd == CMD_CHIP_600mV_AC || cmd == CMD_CHIP_uA_AC ||
           cmd == CMD_CHIP_mA_AC || cmd == CMD_CHIP_10A_AC;
}

// Uložený rozsah pre aktuálnu polohu a sub-mód
static uint8_t *CurRangeMem(void) {
    return &pos_range[cur_pos % NUM_POSITIONS][cur_sub % NUM_SUBMODES];
}

static bool IsManual(void) {
    return *CurRangeMem() != MEAS_RANGE_AUTO;
}

static void Settings_Init(void) {
    for (int p = 0; p < NUM_POSITIONS; p++) {
        pos_sub[p] = ROTARY_GetDefaultSubMode((SwitchPosition_t)p);
        for (int m = 0; m < NUM_SUBMODES; m++) {
            pos_range[p][m] = MEAS_RANGE_AUTO;
        }
    }
}

// Odošle čipu mód podľa aktuálnej polohy a sub-módu vrátane uloženého rozsahu.
// Dáta, ktoré prídu medzitým, sa zahodia (vzorky sa berú iba v stave READY).
static void ApplyMode(void) {
    uint8_t cmd = ROTARY_GetChipCommand(cur_pos, cur_sub);
    MeasChip_SetMode(cmd, ROTARY_GetQuery(cur_pos, cur_sub), *CurRangeMem());
    pending_btn   = BTN_NONE;
    mode_epoch++;
    cx_disp_range = 0;
    if (cur_pos == SWITCH_POS_Cx) {
        rel_active = cx_rel_active;   // Cx: obnoviť REL, ak ho užívateľ zapol
        rel_offset = cx_rel_offset;
        strcpy(rel_text, cx_rel_text);
    } else {
        rel_active = false;           // offset patrí k meranej veličine -> pri zmene sa ruší
    }
    last_sample_ok = false;
    display_dirty = true;
    menu_dirty    = true;
}

// Zmena sub-módu užívateľom: zapamätá sa pre túto polohu a pošle do čipu
static void SelectSubMode(SubMode_t sub) {
    if (sub == cur_sub) return;
    cur_sub = sub;
    pos_sub[cur_pos % NUM_POSITIONS] = sub;
    ApplyMode();
}

// Určí formát vzorky (bodka, popis, jednotka, exponent) pre aktuálnu polohu.
// Vráti false, ak vzorka do aktuálneho módu nepatrí alebo má neplatný rozsah.
static bool GetFormat(const MeasSample_t *s, Format_t *f) {
    uint8_t count;
    const RangeInfo_t *tbl = GetRangeTable(cur_pos, cur_sub, &count);

    f->decimals = 0;
    f->exp      = 0;
    f->label    = "";
    f->unit     = "  ";
    f->acdc     = "  ";
    f->icon     = ICON_NONE;
    f->ol_above = 0;

    if (tbl != NULL) {
        if (s->packet_type != MEAS_QUERY_MAIN) return false;
        if (s->range >= count) return false;      // neplatný / prechodný rozsah (pôvodný mV filter)
        f->decimals = tbl[s->range].decimals;
        f->exp      = tbl[s->range].exp;
        f->label    = tbl[s->range].label;
        f->unit     = tbl[s->range].unit;
        f->ol_above = tbl[s->range].ol_above;
        if (cur_pos == SWITCH_POS_OHM_DIODE_CONT) {
            if (cur_sub == SUB_MODE_DIODE)      f->icon = ICON_DIODE;
            if (cur_sub == SUB_MODE_CONTINUITY) f->icon = ICON_BEEP;
        }
        if (IsVoltCurrentPos(cur_pos)) {
            f->acdc = IsAcMode(ROTARY_GetChipCommand(cur_pos, cur_sub)) ? "AC" : "DC";
        }
    }
    else if (cur_pos == SWITCH_POS_Hz_Pct && cur_sub == SUB_MODE_FREQ) {
        // PREDPOKLAD: 0x61 posiela frekvenciu v mHz (sieť 50 Hz = 50000)
        if (s->packet_type != MEAS_QUERY_FREQ) return false;
        f->decimals = 3;
        f->label = "";
        f->unit  = "Hz";
    }
    else if (cur_pos == SWITCH_POS_Hz_Pct && cur_sub == SUB_MODE_DUTY) {
        // PREDPOKLAD: 0x62 posiela striedu v 0.01 %
        if (s->packet_type != MEAS_QUERY_DUTY) return false;
        f->decimals = 2;
        f->label = "";
        f->unit  = "% ";
    }
    else {
        // dióda / pípak – škálovanie ešte nie je známe, zobrazíme surové číslo
        if (s->packet_type != MEAS_QUERY_MAIN) return false;
        snprintf(f->label_buf, sizeof(f->label_buf), "RNG %u", s->range);
        f->label = f->label_buf;
    }
    return true;
}

// Text korekcie: zachytená hodnota sa odčíta, takže korekcia má opačné znamienko.
// Napr. parazitná kapacita +0.050 nF -> "-0.050 nF".
static void FormatRelText(char *buf, size_t n, int32_t v, int8_t decimals, const char *unit) {
    char sign = (v > 0) ? '-' : (v < 0) ? '+' : ' ';
    uint32_t a = (v < 0) ? (uint32_t)(-(int64_t)v) : (uint32_t)v;
    char num[24];
    if (decimals > 6) decimals = 6;
    if (decimals > 0) {
        uint32_t p = (uint32_t)Pow10((uint8_t)decimals);
        snprintf(num, sizeof(num), "%lu.%0*lu", (unsigned long)(a / p), decimals, (unsigned long)(a % p));
    } else {
        snprintf(num, sizeof(num), "%lu", (unsigned long)a);
    }
    snprintf(buf, n, "%c%s %s", sign, num, unit);
    // odrezať medzery na konci (napr. jednotka "% ")
    size_t len = strlen(buf);
    while (len > 0 && buf[len - 1] == ' ') buf[--len] = '\0';
}

// Je vzorka mimo rozsahu (OL)? Rovnaké pravidlá ako pri zobrazení.
static bool SampleIsOL(const MeasSample_t *smp, const Format_t *f) {
    return smp->overload || (f->ol_above && smp->value > f->ol_above);
}

// REL: prvé stlačenie zachytí aktuálnu hodnotu ako nulu, druhé REL vypne
static void ToggleRel(void) {
    if (rel_active) {
        rel_active = false;
        if (cur_pos == SWITCH_POS_Cx) cx_rel_active = false;
    } else if (last_sample_ok && !last_sample.overload) {
        Format_t f;
        if (GetFormat(&last_sample, &f) &&
            !(f.ol_above && last_sample.value > f.ol_above)) {   // z OL sa REL nezapína
            rel_offset = (int64_t)last_sample.value * Pow10(f.exp);
            rel_active = true;
            if (cur_pos == SWITCH_POS_Cx) {
                // Kapacita: text korekcie v rovnakom formáte ako zobrazenie (napr. "-00.03 nF")
                uint8_t r = 0;
                CxSelectRange(rel_offset, &r);
                const RangeInfo_t *ri = &RANGES_CAP[r];
                FormatRelText(rel_text, sizeof(rel_text),
                              (int32_t)DivRound(rel_offset, Pow10(ri->exp)), ri->decimals, ri->unit);
            } else {
                FormatRelText(rel_text, sizeof(rel_text), last_sample.value, f.decimals, f.unit);
            }
            if (cur_pos == SWITCH_POS_Cx) {           // zapamätať pre Cx
                cx_rel_active = true;
                cx_rel_offset = rel_offset;
                strcpy(cx_rel_text, rel_text);
            }
        }
    }
    display_dirty = true;
    redraw_last   = true;
}

// Spracovanie tlačidiel – všetko v kontexte hlavnej slučky
static void HandleButton(ButtonType_t btn) {
    bool range_pos = HasRangeButton(cur_pos, cur_sub);
    bool ready = (MeasChip.init_state == INIT_STEP_READY);

    switch (btn) {
        case BTN_F1:                       // REL – vynuluje zobrazenie na aktuálnu hodnotu
            is_hold_active = false;
            ToggleRel();
            break;

        case BTN_F2:                       // HOLD
            is_hold_active = !is_hold_active;
            break;

        case BTN_F3:
            is_hold_active = false;
            if (cur_pos == SWITCH_POS_Hz_Pct) {
                SelectSubMode(SUB_MODE_FREQ);                         // F3 = Hz
            } else {
                SelectSubMode(ROTARY_GetNextSubMode(cur_pos, cur_sub)); // SEL
            }
            break;

        case BTN_F4:
            if (cur_pos == SWITCH_POS_Hz_Pct) {                       // F4 = %
                is_hold_active = false;
                SelectSubMode(SUB_MODE_DUTY);
            }
            else if (cur_pos == SWITCH_POS_OHM_DIODE_CONT && cur_sub == SUB_MODE_DIODE) {
                is_hold_active = false;
                SelectSubMode(SUB_MODE_RESISTANCE);                   // skratka dióda -> odpor
            }
            else if (cur_pos == SWITCH_POS_OHM_DIODE_CONT && cur_sub == SUB_MODE_CONTINUITY) {
                is_hold_active = false;
                SelectSubMode(SUB_MODE_DIODE);                        // skratka pípak -> dióda
            }
            else if (range_pos) {                                     // RNG
                is_hold_active = false;
                if (ready) {
                    // Každé stlačenie = ďalší rozsah. Číslo rozsahu sa uloží z odpovede čipu.
                    MeasChip_SetRange(CMD_CHIP_MANUAL);
                } else {
                    // Čip sa práve nastavuje -> vykonáme hneď ako bude pripravený
                    pending_btn = BTN_F4;
                }
            }
            break;

        case BTN_AUTO:                     // návrat do AUTO (zapamätá sa)
            is_hold_active = false;
            pending_btn = BTN_NONE;
            if (IsManual()) {
                *CurRangeMem() = MEAS_RANGE_AUTO;
                if (ready) MeasChip_SetRange(CMD_CHIP_AUTO);
                else       ApplyMode();    // inicializácia beží -> začneme ju znova už s AUTO
            }
            break;

        case BTN_BL: {                     // jas podsvietenia 50 -> 75 -> 25 -> 50 %
            static uint8_t level = 50;
            if (level == 50)      level = 75;
            else if (level == 75) level = 25;
            else                  level = 50;
            LCD_BL_SetBrightness(level);
            return;                        // menu sa nemení
        }

        default:
            return;
    }
    menu_dirty = true;
}

// Po dokončení každého príkazu (READY) skontroluje, či čip potvrdil manuálny rozsah,
// uloží ho do pamäte a prípadne vykoná odložené stlačenie RNG.
static void SyncRangeState(void) {
    static InitState_t last_state = INIT_STEP_IDLE;
    InitState_t st = MeasChip.init_state;

    if (st == INIT_STEP_READY && last_state != INIT_STEP_READY) {
        uint8_t target = MeasChip.manual_target;          // po 5B = potvrdený rozsah, po 5A = AUTO
        if (*CurRangeMem() != target) {
            *CurRangeMem() = target;
            menu_dirty    = true;
            display_dirty = true;
        }
        if (pending_btn == BTN_F4) {
            pending_btn = BTN_NONE;
            MeasChip_SetRange(CMD_CHIP_MANUAL);
            st = MeasChip.init_state;
        }
    }
    last_state = st;
}

#if !DEBUG_SCREEN
// Nadpis meranej veličiny v hornom riadku. Pri výpadku komunikácie sa namiesto neho
// zobrazí červené upozornenie, aby bolo jasné, prečo hodnota stojí.
static const char *GetTitle(void) {
    if (gen_open) return "GENERATOR";
    switch (cur_pos) {
        case SWITCH_POS_V:
        case SWITCH_POS_mV:   return "VOLTAGE";
        case SWITCH_POS_uA:
        case SWITCH_POS_mA:
        case SWITCH_POS_10A:  return "CURRENT";
        case SWITCH_POS_Cx:   return "CAPACITANCE";
        case SWITCH_POS_Hz_Pct:
            return (cur_sub == SUB_MODE_DUTY) ? "DUTY CYCLE" : "FREQUENCY";
        case SWITCH_POS_OHM_DIODE_CONT:
            if (cur_sub == SUB_MODE_DIODE)      return "DIODE";
            if (cur_sub == SUB_MODE_CONTINUITY) return "CONTINUITY";
            return "RESISTANCE";
        default:              return "";
    }
}

static void Display_Title(void) {
    static char     last[28] = "?";
    static uint32_t epoch = 0;
    if (epoch != screen_epoch) { epoch = screen_epoch; strcpy(last, "?"); }
    bool hint = (int32_t)(gen_hint_until - HAL_GetTick()) > 0;
    bool err  = MeasChip.comm_error && !gen_open && !hint;     // v generátore čip nezaujíma
    const char *txt = hint ? "GEN: SWITCH TO V" : err ? "CHIP NEODPOVEDA" : GetTitle();
    uint16_t color  = hint ? LCD_YELLOW : err ? LCD_RED : LCD_CYAN;

    if (strcmp(txt, last) == 0) return;
    strncpy(last, txt, sizeof(last) - 1);
    last[sizeof(last) - 1] = '\0';

    // Šírka textu: 12 px na znak, posledný znak bez 2 px medzery
    int len = (int)strlen(txt);
    if (len > 18) len = 18;
    int w = len * 12 - 2;
    int x;
    if (err || hint) {
        // Rovnaká medzera od časovača (koniec x = 62) aj od batérie (začiatok x = 284)
        x = (62 + 284 - w) / 2;
    } else {
        // Názov veličiny v strede displeja
        x = (320 - w) / 2;
    }

    char buf[20];
    snprintf(buf, sizeof(buf), "%.*s", len, txt);
    LCD_FillRect(64, 10, 218, 16, LCD_BLACK);      // zmazať priestor medzi časovačom a batériou
    LCD_DrawString((uint16_t)x, 10, buf, color, LCD_BLACK, 2);
}

#endif // !DEBUG_SCREEN

// Pin do analógového režimu – v spánku neodoberá žiadny prúd (žiadny pull-up, žiadny vstupný stupeň)
static void PinToAnalog(GPIO_TypeDef *port, uint16_t pins) {
    GPIO_InitTypeDef gi = {0};
    gi.Pin  = pins;
    gi.Mode = GPIO_MODE_ANALOG;
    gi.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(port, &gi);
}

// Automatické vypnutie: odpojí LCD a merací čip, MCU uspí do STOP režimu.
// Zobudí ho stlačenie ľubovoľného tlačidla (EXTI) -> reset -> normálny štart prístroja.
void AutoOff_PowerDown(void) {
    // 0. Generátor: uložiť nastavenie (EEPROM je ešte napájaná) a vypnúť DAC, DMA, TIM6
    Gen_SaveSettings();
    Gen_Stop();

    // 1. Podsvietenie a komunikácia s čipom
    HAL_TIM_PWM_Stop(&htim5, TIM_CHANNEL_4);
    HAL_UART_DeInit(&huart6);
    PinToAnalog(GPIOA, GPIO_PIN_11 | GPIO_PIN_12);      // USART6 TX/RX k vypnutému čipu

    // 1b. ADC a interná referencia VREFINT – inak by ich analógová časť brala prúd aj v STOP
    ADC1->CR2 &= ~ADC_CR2_ADON;
    ADC->CCR  &= ~ADC_CCR_TSVREFE;

    // 2. Napájanie LCD + čipu vypnúť (všetky piny k LCD najprv do 0)
    LCD_Power_Off();

    // 3. Bzučiak do 0, otočný prepínač bez pull-upov (zopnutý kontakt by inak stále odoberal prúd)
    HAL_GPIO_WritePin(Buzzer_GPIO_Port, Buzzer_Pin, GPIO_PIN_RESET);
    PinToAnalog(SW1_GPIO_Port, SW1_Pin | SW2_Pin | SW3_Pin);

    // 4. Tlačidlá ostávajú ako budenie: výstupy matice v 0, vstupy s pull-upom a EXTI na zostupnú hranu
    HAL_GPIO_WritePin(OUT_K246_GPIO_Port, OUT_K246_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(OUT_K357_GPIO_Port, OUT_K357_Pin, GPIO_PIN_RESET);
    HAL_Delay(300);                                      // nech stihne doznieť prípadné stlačenie

    // 5. Všetky ostatné piny do analógového režimu (najnižší únik). Ostávajú iba:
    //    PA0, PA1, PA3 (vstupy matice), PA4, PA6 (výstupy matice v 0), PA2 (napájanie v 0),
    //    PA13, PA14 (SWD – aby sa dal procesor znova naprogramovať), PC9 (tlačidlo BL)
    PinToAnalog(GPIOA, (uint16_t)(GPIO_PIN_All & ~(IN_K6_K7_Pin | IN_K4_K5_Pin | IN_K2_K3_Pin |
                                                   OUT_K357_Pin | OUT_K246_Pin | A3V_Pin |
                                                   GPIO_PIN_13 | GPIO_PIN_14)));
    // GPIOB: LCD zbernica a I2C k EEPROM (PB8, PB9) do analógu; bzučiak PB10 a podsvietenie PB11 ostávajú výstupy v 0,
    //        aby budiace tranzistory nemali plávajúci vstup
    PinToAnalog(GPIOB, (uint16_t)(GPIO_PIN_All & ~(Buzzer_Pin | GPIO_PIN_11)));
    PinToAnalog(GPIOC, (uint16_t)(GPIO_PIN_All & ~IN_K1_Pin));
    PinToAnalog(GPIOH, GPIO_PIN_0 | GPIO_PIN_1);
    __HAL_GPIO_EXTI_CLEAR_IT(IN_K1_Pin | IN_K2_K3_Pin | IN_K4_K5_Pin | IN_K6_K7_Pin);

    // 6. STOP režim s najúspornejším nastavením F410:
    //    nízkoodberový regulátor v nízkom napätí (LPLVDS), flash vypnutá,
    //    ladenie v STOP vypnuté (inak by debug blok držal hodiny bežať)
    DBGMCU->CR &= ~(DBGMCU_CR_DBG_STOP | DBGMCU_CR_DBG_SLEEP | DBGMCU_CR_DBG_STANDBY);
    HAL_SuspendTick();
    HAL_PWREx_EnableFlashPowerDown();
    HAL_PWREx_EnableLowRegulatorLowVoltage();
    HAL_PWR_EnterSTOPMode(PWR_LOWPOWERREGULATOR_ON, PWR_STOPENTRY_WFI);

    // 7. Zobudenie tlačidlom -> čistý reštart celého firmvéru
    NVIC_SystemReset();
}

// Odpočet automatického vypnutia (beží vždy, aj v menu a pri ladiacej obrazovke)
static uint32_t AutoOff_Remaining(void) {
    uint32_t total = AutoOffSeconds();
    if (total == 0) return UINT32_MAX;                 // vypnutie zakázané
    uint32_t elapsed = (HAL_GetTick() - last_activity_tick) / 1000u;
    return (elapsed >= total) ? 0 : (total - elapsed);
}

static void AutoOff_Task(void) {
    // Zakázané auto vypnutie (generátor / osciloskop): krátke pípnutie každých 5 min ako pripomienka
    if (AutoOffSeconds() == 0) {
        if (HAL_GetTick() - gen_beep_tick >= GEN_BEEP_PERIOD_MS) {
            gen_beep_tick = HAL_GetTick();
            Beep(80);
        }
        return;
    }
    if (AutoOff_Remaining() == 0 && !auto_off_done) {
        auto_off_done = true;
        AutoOff_PowerDown();
    }
}

#if !DEBUG_SCREEN

// Odpočet do vypnutia vľavo hore "MM:SS", dvojbodka bliká každých 0.5 s
static void Display_Timer(void) {
    static char     last[16] = "?";
    static uint32_t epoch = 0;
    if (epoch != screen_epoch) { epoch = screen_epoch; last[0] = '?'; last[1] = '\0'; }

    uint32_t now = HAL_GetTick();

    // Auto vypnutie zakázané -> namiesto času nápis
    if (AutoOffSeconds() == 0) {
        if (strcmp(last, "OFF") == 0) return;
        strcpy(last, "OFF");
        LCD_FillRect(2, 8, 62, 20, LCD_BLACK);
        LCD_DrawString(8, 9,  "AUTO OFF", LCD_ORANGE, LCD_BLACK, 1);     // x = 8 ako WAVE pod tým
        LCD_DrawString(8, 19, "DISABLED", LCD_ORANGE, LCD_BLACK, 1);
        return;
    }
    if (strcmp(last, "OFF") == 0) LCD_FillRect(2, 8, 62, 20, LCD_BLACK);   // zmazať malý nápis

    uint32_t remain = AutoOff_Remaining();

    char colon = ((now / 500u) & 1u) ? ' ' : ':';
    char buf[16];
    snprintf(buf, sizeof(buf), "%02lu%c%02lu",
             (unsigned long)(remain / 60u), colon, (unsigned long)(remain % 60u));

    if (strcmp(buf, last) == 0) return;
    strcpy(last, buf);
    LCD_DrawString(4, 10, buf, (remain < 60u) ? LCD_RED : LCD_WHITE, LCD_BLACK, 2);
}

// Batéria vpravo hore – prekreslí sa iba pri zmene percent
static void Display_Battery(void) {
    static uint8_t  last = 0xFF;
    static uint32_t epoch = 0;
    if (epoch != screen_epoch) { epoch = screen_epoch; last = 0xFF; }
    uint8_t pct = Battery_GetPercent();
    if (pct == last) return;
    last = pct;
    LCD_DrawBattery(284, 10, pct);
}

// Hodnota REL korekcie nad tlačidlom REL (prázdne, keď REL nie je aktívne)
static void Display_RelInfo(void) {
    static char     last[20] = "?";
    static uint32_t epoch = 0;
    if (epoch != screen_epoch) { epoch = screen_epoch; strcpy(last, "?"); }

    const char *txt = rel_active ? rel_text : "";
    if (strcmp(txt, last) == 0) return;
    strcpy(last, txt);
    LCD_FillRect(2, 186, 230, 18, LCD_BLACK);
    if (txt[0]) LCD_DrawString(4, 188, txt, LCD_CYAN, LCD_BLACK, 2);
}
// Na obrazovke voltmetra informácia, že beží výstup generátora (s jeho nastavením)
#define GEN_INFO_Y  170          // v strede medzi veľkými číslicami (spodok y = 160) a riadkom REL (y = 188)
static void Display_GenIndicator(void) {
    static char     last[48] = "?";
    static uint32_t epoch = 0;
    if (epoch != screen_epoch) { epoch = screen_epoch; strcpy(last, "?"); }

    char buf[48] = "";
    if (Gen_IsOn()) {
        char f[16], v[16];
        Gen_FormatFreq(Gen_FreqHz(g_gen.freq_idx), f, sizeof(f));
        Gen_FormatVolt(Gen_VoltMv(g_gen.volt_idx), v, sizeof(v));
        if (Gen_DutyUsed(g_gen.wave))
            snprintf(buf, sizeof(buf), "GEN OUTPUT ON: %s %s %u%% %s",
                     Gen_WaveName(g_gen.wave), f, Gen_DutyPct(g_gen.duty_idx), v);
        else
            snprintf(buf, sizeof(buf), "GEN OUTPUT ON: %s %s %s", Gen_WaveName(g_gen.wave), f, v);
    }
    if (strcmp(buf, last) == 0) return;
    strcpy(last, buf);
    LCD_FillRect(2, GEN_INFO_Y, 316, 10, LCD_BLACK);
    if (buf[0]) LCD_DrawString(10, GEN_INFO_Y, buf, LCD_GREEN, LCD_BLACK, 1);   // x = 10 ako veľké číslice
}
#endif // !DEBUG_SCREEN

// Návrat na meraciu obrazovku (z menu alebo generátora): prekresliť všetko
static void ReturnToMeasScreen(void) {
    LCD_Clear(LCD_BLACK);
    screen_epoch++;
    display_dirty = true;
    menu_dirty    = true;
    redraw_last   = true;
}

#if DEBUG_SCREEN
// Stavový riadok – prekreslí sa iba pri zmene
static void Display_Status(void) {
    static InitState_t last_state = (InitState_t)0xFF;
    static bool        last_err   = false;
    static uint8_t     last_mode  = 0xFF;

    InitState_t st  = MeasChip.init_state;
    bool        err = MeasChip.comm_error;
    uint8_t     mode = MeasChip.mode_cmd;

    if (st == last_state && err == last_err && mode == last_mode) return;
    last_state = st;
    last_err   = err;
    last_mode  = mode;

    char buf[26];
    uint16_t color = LCD_WHITE;

    if (err) {
        snprintf(buf, sizeof(buf), "%-25s", "STATUS: CHIP NEODPOVEDA");
        color = LCD_RED;
    } else switch (st) {
        case INIT_STEP_SET_MODE:
        case INIT_STEP_SEND_AUTO:
            snprintf(buf, sizeof(buf), "STATUS: WAIT FOR 58 %02X  ", mode);
            break;
        case INIT_STEP_SET_AUTO:
            snprintf(buf, sizeof(buf), "%-25s", "STATUS: WAIT FOR 5A 00");
            break;
        case INIT_STEP_SET_MAN:
            snprintf(buf, sizeof(buf), "%-25s", "STATUS: WAIT FOR 5B REQ");
            break;
        case INIT_STEP_READY:
            snprintf(buf, sizeof(buf), "%-25s", "STATUS: TELEMETRY ACTIVE");
            color = LCD_GREEN;
            break;
        default:
            snprintf(buf, sizeof(buf), "%-25s", "STATUS: IDLE");
            break;
    }
    LCD_DrawString(10, 10, buf, color, LCD_BLACK, 2);
}

// RAW sniffer – iba keď prišli nové bajty, najviac každých 100 ms
static void Display_Sniffer(void) {
    static uint32_t last_count = 0xFFFFFFFF;
    static uint32_t last_tick  = 0;
    uint8_t snap[16];

    if (debug_rx_count == last_count || (HAL_GetTick() - last_tick) < 100) return;
    last_tick = HAL_GetTick();

    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    last_count = debug_rx_count;
    for (int i = 0; i < 16; i++) snap[i] = debug_rx_buffer[i];
    __set_PRIMASK(primask);

    char hex_string[32];
    snprintf(hex_string, sizeof(hex_string), "%02X %02X %02X %02X %02X %02X %02X %02X",
             snap[0], snap[1], snap[2], snap[3], snap[4], snap[5], snap[6], snap[7]);
    LCD_DrawString(25, 165, hex_string, LCD_YELLOW, LCD_BLACK, 2);
    snprintf(hex_string, sizeof(hex_string), "%02X %02X %02X %02X %02X %02X %02X %02X",
             snap[8], snap[9], snap[10], snap[11], snap[12], snap[13], snap[14], snap[15]);
    LCD_DrawString(25, 185, hex_string, LCD_YELLOW, LCD_BLACK, 2);
}

#endif // DEBUG_SCREEN

// Text sa prekreslí iba ak sa zmenil (cache je pole aspoň 24 znakov)
static void DrawTextIfChanged(char *cache, uint16_t x, uint16_t y, const char *txt, uint16_t color) {
    if (!display_dirty && strcmp(cache, txt) == 0) return;
    strncpy(cache, txt, 23);
    cache[23] = '\0';
    LCD_DrawString(x, y, txt, color, LCD_BLACK, 2);
}

// Veľké číslice + bodka + jednotky. Prekresľuje sa iba to, čo sa zmenilo.
static void Display_Measurement(const MeasSample_t *s) {
    static char    last_digits[6] = "?????";
    static uint8_t last_dot = 0xFF;
    static char    last_top[24], last_acdc[24], last_unit[24];

    const uint16_t txt_color  = LCD_YELLOW;
    const uint16_t digit_step = FONT_7SEG_WIDTH + 12;   // krok pre 45 px široké číslice
    const uint16_t units_x    = 10 + (5 * digit_step);  // jednotky na pravom okraji
    const uint16_t dot_size   = 7;
    const uint16_t dot_y      = DIGITS_Y + (FONT_7SEG_HEIGHT - dot_size);

    const char *range_mode_str = IsManual() ? "MAN " : "AUTO";
    Format_t    f;
    if (!GetFormat(s, &f)) return;

    int8_t      decimals = f.decimals;
    const char *label = f.label;
    const char *unit  = f.unit;
    const char *acdc  = f.acdc;
    int32_t     v  = s->value;
    bool        ol = s->overload;

    // Mimo rozsahu čipu (napr. odpor > 60 MΩ, dióda naprázdno, rozpojený pípak)
    if (f.ol_above && v > f.ol_above) ol = true;

    // --- Kapacita: automatická voľba jednotky nF / uF / mF podľa veľkosti hodnoty ---
    // Hodnota sa prepočíta na pF podľa rozsahu z čipu, odčíta sa REL a vyberie sa
    // zobrazovací rozsah (9999 digitov, s hysterézou).
    if (cur_pos == SWITCH_POS_Cx && !ol) {
        int64_t pf = (int64_t)v * Pow10(f.exp);
        if (rel_active) pf -= rel_offset;

        if (!CxSelectRange(pf, &cx_disp_range)) {
            ol = true;                                // nad 99.99 mF
        } else {
            const RangeInfo_t *ri = &RANGES_CAP[cx_disp_range];
            v        = (int32_t)DivRound(pf, Pow10(ri->exp));
            decimals = ri->decimals;
            label    = ri->label;
            unit     = ri->unit;
        }
    }
    // --- REL: odčítanie offsetu v základných jednotkách, výsledok v rozlíšení aktuálneho rozsahu ---
    else if (rel_active && !ol) {
        int64_t p    = Pow10(f.exp);
        int64_t diff = DivRound((int64_t)v * p - rel_offset, p);
        if (diff > 99999999LL || diff < -99999999LL) ol = true;
        else v = (int32_t)diff;
    }

    // --- Zmenšenie na 4 číslice (ubúdajú desatinné miesta, potom OL) ---
    bool neg = (v < 0);
    uint32_t a = neg ? (uint32_t)(-(int64_t)v) : (uint32_t)v;
    while (!ol && a > 9999) {
        if (decimals > 0) {
            a /= 10;
            decimals--;
        } else {
            ol = true;                            // viac ako 4 číslice -> mimo rozsah
        }
    }

    // --- Bodka ---
    uint8_t dot = (ol || decimals == 0) ? 0 : (uint8_t)(5 - decimals);
    if (dot != last_dot || display_dirty) {
        for (uint16_t r = 0; r < dot_size; r++) {
            for (uint8_t k = 2; k <= 4; k++) {
                LCD_DrawFastHLine(10 + (k * digit_step) - 10, dot_y + r, 10, LCD_BLACK);
            }
        }
        last_dot = dot;
    }

    // --- Veľké číslice (pri pretečení "OL" tým istým fontom, prekresľujú sa iba zmenené) ---
    char digits[16];
    if (ol) {
        strcpy(digits, "  0L ");             // v strede: 2. a 3. pozícia zo 4 číslic (0 namiesto O)
    } else {
        snprintf(digits, sizeof(digits), "%c%04lu", neg ? '-' : ' ', (unsigned long)a);
    }
    for (int i = 0; i < 5; i++) {
        if (display_dirty || digits[i] != last_digits[i]) {
            LCD_Draw7SegDigit(10 + i * digit_step, DIGITS_Y, digits[i], txt_color, LCD_BLACK);
            last_digits[i] = digits[i];
        }
    }
    if (dot) {
        LCD_Draw7SegDot(10 + (dot * digit_step) - 9, DIGITS_Y, txt_color, LCD_BLACK);
    }

    // --- Texty: horný riadok, AC/DC a jednotka na okraji ---
    char tmp[24], buf[24];
    if (label[0] != '\0') {
        snprintf(tmp, sizeof(tmp), "%s%s %s %s", range_mode_str, rel_active ? " REL" : "", label, unit);
    } else {
        // dióda, Hz, % – iba AUTO (+ REL), jednotka je vpravo pri číslach
        snprintf(tmp, sizeof(tmp), "%s%s", range_mode_str, rel_active ? " REL" : "");
    }
    snprintf(buf, sizeof(buf), "%-20s", tmp);
    DrawTextIfChanged(last_top, 20, 45, buf, LCD_WHITE);

    // AC/DC alebo ikona (dióda, pípak) na tom istom mieste
    char acdc_key[4];
    if (f.icon) { acdc_key[0] = (char)f.icon; acdc_key[1] = '\0'; }
    else        { strncpy(acdc_key, acdc, 3); acdc_key[3] = '\0'; }
    if (display_dirty || strcmp(last_acdc, acdc_key) != 0) {
        strcpy(last_acdc, acdc_key);
        LCD_FillRect(units_x - 5, ACDC_Y, 24, 16, LCD_BLACK);   // zmazať celé miesto (text nekreslí medzery medzi znakmi)
        if (f.icon) LCD_DrawIcon(units_x - 5, ACDC_Y, f.icon, LCD_CYAN, LCD_BLACK, 2);
        else        LCD_DrawString(units_x - 5, ACDC_Y, acdc, (acdc[0] == 'A') ? LCD_ORANGE : LCD_GREEN, LCD_BLACK, 2);
    }

    snprintf(buf, sizeof(buf), "%-2s", unit);
    DrawTextIfChanged(last_unit, units_x - 5, UNIT_Y, buf, txt_color);

    display_dirty = false;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART6_UART_Init();
  MX_TIM5_Init();
  /* USER CODE BEGIN 2 */

  LCD_PWR_PORT->BSRR = (1 << (LCD_PWR_PIN + 16));
  HAL_Delay(250);

  // Napájanie a inicializácia displeja
  LCD_Power_Accessories();
  LCD_Init_Hardware();

  // Stav ovládača čipu + spustenie príjmu cez prerušenie
  MeasChip_Init();
  HAL_UART_Receive_IT(&huart6, &rx_byte, 1);

  LCD_Init();
  BUTTON_Init();
  Settings_Init();
  Battery_Init();                        // ADC1: PA7 (U_bat, delič 10k/10k) + VREFINT
  EEPROM_Init();                         // I2C1 + EEPROM (po zapnutí PA2, ak je napájaná z neho)
  Settings_Load();                       // užívateľské nastavenia z EEPROM (pri chybe predvolené)
  Gen_LoadSettings();                    // posledné nastavenie generátora (výstup vypnutý)

  LCD_DrawString(85, 200, "Firmware v0.45", LCD_YELLOW, LCD_BLACK, 2);
  LCD_DrawString(10, 100, "INITIALIZING MEAS CHIP...", LCD_WHITE, LCD_BLACK, 2);

  // Čakanie na uvítací paket A0 01 A1
  while (!MeasChip.chip_present) {
      HAL_Delay(100);
  }
  LCD_DrawString(10, 100, "   MEAS CHIP BOOTED OK     ", LCD_GREEN, LCD_BLACK, 2);
  HAL_Delay(900);

  LCD_Clear(LCD_BLACK);
  last_activity_tick = HAL_GetTick();   // štart odpočtu automatického vypnutia

  /* USER CODE END 2 */



  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

      BUTTON_Poll();                            // pustenie tlačidiel (zvýraznenie, dlhé F1, opakovanie)
      ButtonType_t btn = BUTTON_GetEvent();
      if (btn != BTN_NONE) {
          NoteActivity();                       // reštart odpočtu (ak je zapnutý Auto reset time)
      }
      // Tlačidlo podsvietenia funguje vždy: krátke = jas, dlhé = generátor
      bool bl_long = false;
      if (btn == BTN_BL) {
          bl_pending = true;
          bl_tick = HAL_GetTick();
          btn = BTN_NONE;
      }
      if (bl_pending) {
          if (BUTTON_GetHeld() == BTN_BL) {
              if (HAL_GetTick() - bl_tick >= BL_LONG_PRESS_MS) {
                  bl_pending = false;
                  bl_long = true;
              }
          } else {
              bl_pending = false;
              HandleButton(BTN_BL);                 // krátke stlačenie -> jas
          }
      }
      if (bl_long && !menu_open) {
          if (gen_open) {                           // odchod z generátora (výstup beží ďalej)
              gen_open = false;
              GenMenu_Close();
              Gen_SaveSettings();                   // do EEPROM, iba ak sa nastavenie zmenilo
              ReturnToMeasScreen();
              last_activity_tick = HAL_GetTick();   // nový odpočet podľa času voltmetra
          } else if (cur_pos == SWITCH_POS_V) {     // generátor iba v polohe V
              if (!Gen_IsOn()) Gen_LoadSettings();  // nastavenie z EEPROM (pri bežiacom výstupe je aktuálne)
              gen_open = true;
              f1_pending = false;
              GenMenu_Open();
              screen_epoch++;                       // horný riadok (čas, nadpis, batéria) znova
              last_activity_tick = HAL_GetTick();   // odpočet podľa času generátora
              gen_beep_tick = HAL_GetTick();
          } else {
              gen_hint_until = HAL_GetTick() + GEN_HINT_MS;
          }
      }

      // --- Komunikácia s čipom beží vždy (aj v menu) ---
      MeasChip_Task();
      SyncRangeState();
      AutoOff_Task();
      Battery_Task();                           // meranie batérie každé 2 s

      // ===================== MENU =====================
      if (menu_open) {
          uint32_t now_m = HAL_GetTick();
          last_activity_tick = now_m;              // odpočet vypnutia v menu stojí
          if (btn != BTN_NONE || BUTTON_GetHeld() != BTN_NONE) {
              menu_input_tick = now_m;
          } else if (now_m - menu_input_tick >= MENU_IDLE_MS) {
              btn = BTN_F1;                        // 2 min bez dotyku -> ako EXIT (uloží nastavenia)
          }
          if (!Menu_Task(btn)) {
              // Návrat z menu: prekresliť celú meraciu obrazovku, odpočet podľa nového nastavenia
              menu_open = false;
              ReturnToMeasScreen();
              last_activity_tick = HAL_GetTick();
          }
          MeasSample_t dummy;
          if (MeasChip_GetSample(&dummy) && MeasChip.init_state == INIT_STEP_READY) {
              Format_t chk;
              if (GetFormat(&dummy, &chk)) { last_sample = dummy; last_sample_ok = true; }
          }
          HAL_Delay(2);
          continue;
      }

      // --- 1. Otočný prepínač (odrušený) ---
      // Výstup generátora je na svorke iba v polohe V -> mimo nej sa vypne
      // a obrazovka generátora sa zavrie.
      SwitchPosition_t new_pos;
      if (ROTARY_PollStable(&new_pos)) {
          cur_pos = new_pos;
          cur_sub = pos_sub[cur_pos % NUM_POSITIONS];   // posledná voľba užívateľa v tejto polohe
          is_hold_active = false;          // otočenie vždy ruší HOLD
          f1_pending = false;
          NoteActivity();
          ApplyMode();
          if (cur_pos != SWITCH_POS_V) {
              if (Gen_IsOn()) {                     // vypnúť, ale zapamätať (RAM) -> po návrate do V zapnúť
                  Gen_SetOutput(false);
                  gen_resume = true;
              }
              if (gen_open) {
                  gen_open = false;
                  GenMenu_Close();
                  Gen_SaveSettings();
                  ReturnToMeasScreen();
                  last_activity_tick = HAL_GetTick();
                  btn = BTN_NONE;                   // stlačenie patrilo generátoru
              }
          } else if (gen_resume) {                  // späť v polohe V: výstup znova zapnúť
              gen_resume = false;
              Gen_SetOutput(true);
          }
      }

      // ================== GENERÁTOR ==================
      // Meranie beží ďalej na pozadí (vzorky sa iba ukladajú), odpočet vypnutia beží normálne.
      if (gen_open) {
          GenMenu_Task(btn);
#if !DEBUG_SCREEN
          Display_Timer();
          Display_Title();
          Display_Battery();
#endif
          MeasSample_t gs;
          if (MeasChip_GetSample(&gs) && MeasChip.init_state == INIT_STEP_READY) {
              Format_t chk;
              if (GetFormat(&gs, &chk)) { last_sample = gs; last_sample_ok = true; }
          }
          HAL_Delay(2);
          continue;
      }

      // --- 2. Tlačidlá ---
      if (btn == BTN_F1) {
          // F1: zatiaľ nič – krátke stlačenie = REL pri pustení, dlhé = menu
          f1_pending = true;
          f1_tick = HAL_GetTick();
      } else if (btn != BTN_NONE) {
          HandleButton(btn);
      }

      if (f1_pending) {
          if (BUTTON_GetHeld() == BTN_F1) {
              if (HAL_GetTick() - f1_tick >= F1_LONG_PRESS_MS) {
                  f1_pending = false;
                  menu_open = true;
                  menu_input_tick = HAL_GetTick();
                  Menu_Open();
                  continue;
              }
          } else {
              f1_pending = false;
              HandleButton(BTN_F1);         // krátke stlačenie -> REL
          }
      }

      // Zvýraznenie SELECT / RANGE iba kým je tlačidlo držané
      {
          static int8_t last_pressed = -1;
          ButtonType_t held = BUTTON_GetHeld();
          int8_t pressed = (held == BTN_F3) ? 2 : (held == BTN_F4) ? 3 : -1;
          if (pressed != last_pressed) {
              last_pressed = pressed;
              pressed_cell = pressed;
              menu_dirty = true;
          }
      }

      // --- 3. Displej ---
      if (menu_dirty) {
          menu_dirty = false;
          LCD_DrawBottomMenu(cur_pos, cur_sub, rel_active, pressed_cell);
      }

#if DEBUG_SCREEN
      Display_Status();
      Display_Sniffer();
#else
      Display_Timer();
      Display_Title();
      Display_Battery();
      Display_RelInfo();
      Display_GenIndicator();
#endif

      MeasSample_t sample;
      if (MeasChip_GetSample(&sample)) {
          // Vzorky mimo READY môžu byť ešte zo starého módu -> zahodiť.
          if (MeasChip.init_state == INIT_STEP_READY) {
              Format_t chk;
              if (GetFormat(&sample, &chk)) {
                  last_sample    = sample;       // pre REL aj počas HOLD
                  last_sample_ok = true;

                  // Probe reset: v Ω / dióde / pípaku priloženie hrotov (OL -> hodnota) reštartuje odpočet
                  static bool prev_ol = false;
                  static uint32_t prev_epoch_mode = 0;
                  if (prev_epoch_mode != mode_epoch) { prev_epoch_mode = mode_epoch; prev_ol = false; }
                  bool ol = SampleIsOL(&sample, &chk);
                  if (cur_pos == SWITCH_POS_OHM_DIODE_CONT && g_settings.probe_reset && prev_ol && !ol) {
                      last_activity_tick = HAL_GetTick();
                  }
                  prev_ol = ol;

                  // Probe reset pri Cx: rozpojené hroty ukazujú len kapacitu káblov (~0.03 nF),
                  // OL sa neobjaví. Pripojenie kondenzátora = hodnota z čipu nad 0.100 nF
                  // dve merania po sebe. Ďalší reset až po poklese pod 0.070 nF (odpojenie).
                  // Prahy sú z hodnoty čipu (pred REL) – kapacita káblov sa REL nemení.
                  static bool     cx_armed = false;
                  static uint8_t  cx_above = 0;
                  static uint32_t cx_epoch = 0;
                  if (cx_epoch != mode_epoch) { cx_epoch = mode_epoch; cx_armed = false; cx_above = 0; }
                  if (cur_pos == SWITCH_POS_Cx && g_settings.probe_reset) {
                      int64_t pf = sample.overload ? CX_PROBE_ON_PF + 1
                                                   : (int64_t)sample.value * Pow10(chk.exp);
                      if (pf < CX_PROBE_OFF_PF) {
                          cx_armed = true;               // hroty voľné -> pripravené na ďalší reset
                          cx_above = 0;
                      } else if (pf > CX_PROBE_ON_PF) {
                          if (cx_armed && ++cx_above >= CX_PROBE_CONFIRM) {
                              last_activity_tick = HAL_GetTick();
                              cx_armed = false;
                              cx_above = 0;
                          }
                      } else {
                          cx_above = 0;                  // medzi prahmi – nič
                      }
                  }
              }
              if (!is_hold_active) {
                  Display_Measurement(&sample);
              }
#if CX_RAW_INFO && !DEBUG_SCREEN
              {
                  static char last_raw[40] = "";
                  char raw[40] = "";
                  if (cur_pos == SWITCH_POS_Cx) {
                      snprintf(raw, sizeof(raw), "RAW: value=%ld range=%u%s     ",
                               (long)sample.value, sample.range, sample.overload ? " OL" : "");
                  }
                  if (strcmp(raw, last_raw) != 0) {
                      strcpy(last_raw, raw);
                      LCD_FillRect(2, 172, 250, 10, LCD_BLACK);
                      if (raw[0]) LCD_DrawString(10, 172, raw, LCD_LIGHTGREY, LCD_BLACK, 1);
                  }
              }
#endif
          }
      }

      // Po stlačení REL / návrate z menu hneď prekresliť poslednú hodnotu
      if (redraw_last) {
          redraw_last = false;
          if (last_sample_ok && !is_hold_active) {
              Display_Measurement(&last_sample);
          }
      }

      HAL_Delay(2);
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 100;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;   // 50 MHz (TIM6 generátora 100 MHz)
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART6) {
        MeasChip_ProcessByte(rx_byte);

#if DEBUG_SCREEN
        // Debug sniffer – posledných 16 bajtov
        if (debug_rx_index < 16) {
            debug_rx_buffer[debug_rx_index++] = rx_byte;
        } else {
            for (int i = 0; i < 15; i++) {
                debug_rx_buffer[i] = debug_rx_buffer[i + 1];
            }
            debug_rx_buffer[15] = rx_byte;
        }
        debug_rx_count++;
#endif

        HAL_UART_Receive_IT(&huart6, &rx_byte, 1);
    }
}

// Pri pretečení (ORE) HAL ukončí príjem cez IT a zavolá tento callback.
// Bez neho by sa príjem z čipu natrvalo zastavil.
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == USART6) {
        __HAL_UART_CLEAR_OREFLAG(huart);
        MeasChip_ResetParser();
        HAL_UART_Receive_IT(&huart6, &rx_byte, 1);   // pri neblokujúcej chybe vráti BUSY – nevadí
    }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
