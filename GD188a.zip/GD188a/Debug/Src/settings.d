Src/settings.o: ../Src/settings.c ../Inc/settings.h ../Inc/eeprom.h \
 ../Inc/eeprom_map.h
../Inc/settings.h:
../Inc/eeprom.h:
../Inc/eeprom_map.h:
