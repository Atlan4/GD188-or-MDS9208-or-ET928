Src/ee_migrate.o: ../Src/ee_migrate.c ../Inc/ee_migrate.h ../Inc/eeprom.h \
 ../Inc/eeprom_map.h ../Inc/eeprom_map.h ../Inc/settings.h
../Inc/ee_migrate.h:
../Inc/eeprom.h:
../Inc/eeprom_map.h:
../Inc/eeprom_map.h:
../Inc/settings.h:
