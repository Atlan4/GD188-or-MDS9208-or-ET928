Src/gen_preset.o: ../Src/gen_preset.c ../Inc/gen_preset.h ../Inc/gen.h \
 ../Inc/eeprom.h ../Inc/eeprom_map.h
../Inc/gen_preset.h:
../Inc/gen.h:
../Inc/eeprom.h:
../Inc/eeprom_map.h:
